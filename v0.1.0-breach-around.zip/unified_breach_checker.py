#!/usr/bin/env python3
"""
Breach Around - Breach Checker and OSINT toolkit
Checks credentials against multiple breach databases and APIs
"""
import os
import sys
import json
import csv
import argparse
import logging
from typing import List, Dict, Optional
from datetime import datetime
from pathlib import Path
from dotenv import load_dotenv

# Load environment variables
load_dotenv()

# Add project root to path
sys.path.append(os.path.dirname(os.path.abspath(__file__)))

from utils.credential_parser import load_credentials_from_csv, Credential
from breach_apis.proxynova_comb import ProxyNovaCOMBChecker
from breach_apis.haveibeenpwned import HaveIBeenPwnedChecker
from breach_apis.leakcheck import LeakCheckChecker

# Configure logging
logging.basicConfig(
    level=logging.INFO,
    format='%(asctime)s - %(levelname)s - %(message)s',
    handlers=[
        logging.FileHandler('logs/breach_checker.log'),
        logging.StreamHandler()
    ]
)
logger = logging.getLogger(__name__)


class UnifiedBreachChecker:
    """
    Unified breach checker that can use multiple services.
    """

    def __init__(
        self,
        use_proxynova: bool = True,
        use_hibp: bool = False,
        use_leakcheck: bool = False,
        hibp_api_key: Optional[str] = None,
        leakcheck_api_key: Optional[str] = None
    ):
        """
        Initialize unified breach checker.

        Args:
            use_proxynova: Enable ProxyNova COMB checker (free)
            use_hibp: Enable Have I Been Pwned checker
            use_leakcheck: Enable LeakCheck checker
            hibp_api_key: HIBP API key (optional)
            leakcheck_api_key: LeakCheck API key (required if use_leakcheck=True)
        """
        self.checkers = []

        # Initialize ProxyNova COMB checker (free)
        if use_proxynova:
            logger.info("Initializing ProxyNova COMB checker...")
            self.checkers.append(('ProxyNova', ProxyNovaCOMBChecker()))

        # Initialize HIBP checker
        if use_hibp:
            logger.info("Initializing Have I Been Pwned checker...")
            self.checkers.append(('HIBP', HaveIBeenPwnedChecker(api_key=hibp_api_key)))

        # Initialize LeakCheck checker
        if use_leakcheck:
            if not leakcheck_api_key:
                logger.warning("LeakCheck API key not provided, skipping LeakCheck")
            else:
                logger.info("Initializing LeakCheck checker...")
                self.checkers.append(('LeakCheck', LeakCheckChecker(api_key=leakcheck_api_key)))

        if not self.checkers:
            raise ValueError("At least one checker must be enabled")

        logger.info(f"Initialized {len(self.checkers)} checker(s): {[name for name, _ in self.checkers]}")

    def check_credential(self, credential: Credential) -> Dict:
        """
        Check a credential against all enabled services.

        Args:
            credential: Credential to check

        Returns:
            Dict with results from all services
        """
        results = {
            'email': credential.email,
            'password': credential.password,
            'timestamp': datetime.now().isoformat(),
            'services': {}
        }

        for service_name, checker in self.checkers:
            try:
                logger.info(f"Checking {credential.email} with {service_name}...")
                service_result = checker.check_credential(credential)
                results['services'][service_name] = service_result
            except Exception as e:
                logger.error(f"Error checking {credential.email} with {service_name}: {e}")
                results['services'][service_name] = {
                    'status': 'error',
                    'error': str(e)
                }

        # Aggregate results
        results['summary'] = self._aggregate_results(results['services'])

        return results

    def _aggregate_results(self, service_results: Dict) -> Dict:
        """
        Aggregate results from all services.

        Args:
            service_results: Results from all services

        Returns:
            Aggregated summary
        """
        summary = {
            'total_breaches': 0,
            'password_compromised': False,
            'clean_services': [],
            'breached_services': [],
            'error_services': []
        }

        for service, result in service_results.items():
            status = result.get('status', 'unknown')

            if status == 'clean':
                summary['clean_services'].append(service)
            elif status in ['breached', 'pwned']:
                summary['breached_services'].append(service)
                summary['total_breaches'] += result.get('breach_count', 0)

                # Check if password was compromised
                if result.get('password_compromised') or result.get('password_status', {}).get('status') == 'pwned':
                    summary['password_compromised'] = True
            elif status == 'error':
                summary['error_services'].append(service)

        # Determine overall status
        if summary['breached_services']:
            summary['overall_status'] = 'breached'
        elif summary['error_services'] and not summary['clean_services']:
            summary['overall_status'] = 'error'
        else:
            summary['overall_status'] = 'clean'

        return summary

    def check_credentials_batch(
        self,
        credentials: List[Credential],
        output_csv: Optional[str] = None,
        output_json: Optional[str] = None,
        detailed_log: Optional[str] = None
    ):
        """
        Check multiple credentials in batch.

        Args:
            credentials: List of credentials to check
            output_csv: Path to CSV output file
            output_json: Path to JSON output file
            detailed_log: Path to detailed log file
        """
        logger.info(f"Starting batch check of {len(credentials)} credentials...")

        results = []

        for i, credential in enumerate(credentials, 1):
            logger.info(f"[{i}/{len(credentials)}] Checking {credential.email}...")

            result = self.check_credential(credential)
            results.append(result)

            # Print summary
            summary = result['summary']
            status_emoji = {
                'clean': '✓',
                'breached': '⚠',
                'error': '✗'
            }.get(summary['overall_status'], '?')

            pwd_status = ' - PASSWORD COMPROMISED!' if summary['password_compromised'] else ''
            logger.info(f"  {status_emoji} {summary['overall_status'].upper()}{pwd_status}")

        # Save results
        if output_csv:
            self._save_csv(results, output_csv)
            logger.info(f"CSV results saved to {output_csv}")

        if output_json:
            self._save_json(results, output_json)
            logger.info(f"JSON results saved to {output_json}")

        if detailed_log:
            self._save_detailed_log(results, detailed_log)
            logger.info(f"Detailed log saved to {detailed_log}")

        # Print summary
        self._print_summary(results)

        return results

    def _save_csv(self, results: List[Dict], output_path: str):
        """Save results to CSV file."""
        Path(output_path).parent.mkdir(parents=True, exist_ok=True)

        with open(output_path, 'w', newline='', encoding='utf-8') as f:
            fieldnames = [
                'email',
                'password',
                'overall_status',
                'total_breaches',
                'password_compromised',
                'breached_services',
                'clean_services'
            ]
            writer = csv.DictWriter(f, fieldnames=fieldnames)
            writer.writeheader()

            for result in results:
                summary = result['summary']
                writer.writerow({
                    'email': result['email'],
                    'password': result.get('password', 'N/A'),
                    'overall_status': summary['overall_status'],
                    'total_breaches': summary['total_breaches'],
                    'password_compromised': 'YES' if summary['password_compromised'] else 'NO',
                    'breached_services': ', '.join(summary['breached_services']),
                    'clean_services': ', '.join(summary['clean_services'])
                })

    def _save_json(self, results: List[Dict], output_path: str):
        """Save results to JSON file."""
        Path(output_path).parent.mkdir(parents=True, exist_ok=True)

        with open(output_path, 'w', encoding='utf-8') as f:
            json.dump(results, f, indent=2, ensure_ascii=False)

    def _save_detailed_log(self, results: List[Dict], output_path: str):
        """Save detailed log file."""
        Path(output_path).parent.mkdir(parents=True, exist_ok=True)

        with open(output_path, 'w', encoding='utf-8') as f:
            f.write("=" * 80 + "\n")
            f.write(f"Unified Breach Check Report - {datetime.now()}\n")
            f.write("=" * 80 + "\n\n")

            for result in results:
                f.write("\n" + "=" * 80 + "\n")
                f.write(f"Email: {result['email']}\n")
                f.write(f"Password: {result.get('password', 'N/A')}\n")
                f.write(f"Timestamp: {result['timestamp']}\n")
                f.write("-" * 80 + "\n")

                summary = result['summary']
                f.write(f"Overall Status: {summary['overall_status'].upper()}\n")
                f.write(f"Total Breaches: {summary['total_breaches']}\n")
                f.write(f"Password Compromised: {'YES ⚠' if summary['password_compromised'] else 'NO'}\n")
                f.write(f"Breached Services: {', '.join(summary['breached_services']) or 'None'}\n")
                f.write(f"Clean Services: {', '.join(summary['clean_services']) or 'None'}\n")

                f.write("\n" + "-" * 80 + "\n")
                f.write("Service Details:\n")
                f.write("-" * 80 + "\n")

                for service, service_result in result['services'].items():
                    f.write(f"\n{service}:\n")
                    f.write(json.dumps(service_result, indent=2) + "\n")

    def _print_summary(self, results: List[Dict]):
        """Print summary statistics."""
        total = len(results)
        breached = sum(1 for r in results if r['summary']['overall_status'] == 'breached')
        clean = sum(1 for r in results if r['summary']['overall_status'] == 'clean')
        errors = sum(1 for r in results if r['summary']['overall_status'] == 'error')
        pwd_compromised = sum(1 for r in results if r['summary']['password_compromised'])

        logger.info("\n" + "=" * 80)
        logger.info("SUMMARY")
        logger.info("=" * 80)
        logger.info(f"Total Checked: {total}")
        logger.info(f"Breached: {breached} ({breached/total*100:.1f}%)")
        logger.info(f"Clean: {clean} ({clean/total*100:.1f}%)")
        logger.info(f"Errors: {errors} ({errors/total*100:.1f}%)")
        logger.info(f"Password Compromised: {pwd_compromised} ({pwd_compromised/total*100:.1f}%)")
        logger.info("=" * 80)


def main():
    """Main entry point."""
    parser = argparse.ArgumentParser(
        description='Unified Breach Around - Breach Checker and OSINT toolkit - Check credentials against multiple breach databases'
    )
    parser.add_argument('input_file', help='Input CSV file with credentials')
    parser.add_argument('-o', '--output', default='results/breach_check', help='Output file prefix')
    parser.add_argument('--proxynova', action='store_true', default=True, help='Use ProxyNova COMB (default: True)')
    parser.add_argument('--hibp', action='store_true', help='Use Have I Been Pwned')
    parser.add_argument('--leakcheck', action='store_true', help='Use LeakCheck')
    parser.add_argument('--hibp-key', help='HIBP API key')
    parser.add_argument('--leakcheck-key', help='LeakCheck API key')

    args = parser.parse_args()

    # Create output directories
    Path('logs').mkdir(exist_ok=True)
    Path('results').mkdir(exist_ok=True)

    # Get API keys from env or args
    hibp_key = args.hibp_key or os.getenv('HIBP_API_KEY')
    leakcheck_key = args.leakcheck_key or os.getenv('LEAKCHECK_API_KEY')

    # Initialize checker
    checker = UnifiedBreachChecker(
        use_proxynova=args.proxynova,
        use_hibp=args.hibp,
        use_leakcheck=args.leakcheck,
        hibp_api_key=hibp_key,
        leakcheck_api_key=leakcheck_key
    )

    # Load credentials
    logger.info(f"Loading credentials from {args.input_file}...")
    credentials = load_credentials_from_csv(args.input_file)
    logger.info(f"Loaded {len(credentials)} credentials")

    # Generate output filenames
    timestamp = datetime.now().strftime('%Y%m%d_%H%M%S')
    output_csv = f"{args.output}_{timestamp}.csv"
    output_json = f"{args.output}_{timestamp}.json"
    detailed_log = f"{args.output}_{timestamp}_detailed.txt"

    # Check credentials
    checker.check_credentials_batch(
        credentials,
        output_csv=output_csv,
        output_json=output_json,
        detailed_log=detailed_log
    )


if __name__ == '__main__':
    main()
