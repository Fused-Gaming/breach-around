#!/usr/bin/env python3
"""
Script to check email addresses from list.csv against ProxyNova COMB API
and log results to result-list.csv with detailed breach information
"""

import csv
import requests
import time
import json
from typing import Dict, Optional, Tuple
from datetime import datetime


def extract_email_and_password(line: str) -> Tuple[Optional[str],
                                                   Optional[str]]:
    """
    Extract email and password from CSV line.
    Format: email:password | Balance = X | CertificateValue = Y
    """
    if not line or line.strip() == '':
        return None, None

    # Split by pipe first to isolate email:password part
    parts = line.split('|')
    if len(parts) >= 1:
        cred_part = parts[0].strip()
        # Now split by colon
        cred_parts = cred_part.split(':', 1)
        if len(cred_parts) >= 1:
            email = cred_parts[0].strip()
            password = cred_parts[1].strip() if len(cred_parts) > 1 else None
            if '@' in email:
                return email, password
    return None, None


def query_api(email: str, start: int = 0,
              limit: int = 100) -> Optional[Dict]:
    """Query ProxyNova COMB API for given email - searches by full email."""
    try:
        # Query with full email for better matching
        base_url = "https://api.proxynova.com/comb"
        url = f"{base_url}?query={email}&start={start}&limit={limit}"
        response = requests.get(url, timeout=10)

        if response.status_code == 200:
            return response.json()
        else:
            msg = f"  [!] API returned status {response.status_code}"
            print(f"{msg} for {email}")
            return None
    except requests.exceptions.RequestException as e:
        print(f"  [!] Error querying {email}: {e}")
        return None
    except json.JSONDecodeError:
        print(f"  [!] Invalid JSON response for {email}")
        return None


def analyze_breach_data(email: str, original_password: Optional[str],
                        api_result: Dict) -> Dict:
    """Analyze breach data and extract detailed information."""
    lines = api_result.get('lines', [])
    count = api_result.get('count', 0)

    # Parse breach entries
    exact_matches = []
    related_entries = []
    unique_passwords = set()
    password_match = False

    for line in lines:
        if ':' in line:
            breach_email, breach_password = line.split(':', 1)

            # Check if it's an exact email match
            if breach_email.lower() == email.lower():
                exact_matches.append(line)
                unique_passwords.add(breach_password)

                # Check if password matches original
                if original_password and breach_password == original_password:
                    password_match = True
            else:
                related_entries.append(line)

    return {
        'total_count': count,
        'exact_matches': len(exact_matches),
        'related_entries': len(related_entries),
        'unique_passwords': list(unique_passwords),
        'password_in_breach': password_match,
        'all_exact_entries': exact_matches,
        'all_related_entries': related_entries
    }


def process_file(input_file: str, output_file: str, detailed_log: str):
    """Process a single CSV file and generate reports."""
    print(f"\n[*] Reading emails from {input_file}...")

    # Read and extract emails with passwords
    credentials = []
    with open(input_file, 'r', encoding='utf-8') as f:
        for i, line in enumerate(f, 1):
            if i == 1:  # Skip header
                continue
            email, password = extract_email_and_password(line)
            if email:
                credentials.append((email, password))

    if not credentials:
        print(f"[!] No valid credentials found in {input_file}")
        return

    print(f"[*] Found {len(credentials)} email addresses to check")
    print("[*] Starting API queries (this may take a while)...\n")

    # Open output files
    with open(output_file, 'w', newline='', encoding='utf-8') as csvfile, \
            open(detailed_log, 'w', encoding='utf-8') as logfile:

        # CSV output
        fieldnames = [
            'email',
            'original_password',
            'total_breaches',
            'exact_email_matches',
            'password_compromised',
            'unique_passwords_found',
            'all_breached_entries'
        ]
        writer = csv.DictWriter(csvfile, fieldnames=fieldnames)
        writer.writeheader()

        # Log header
        logfile.write("="*80 + "\n")
        logfile.write(f"Breach Check Report - {datetime.now()}\n")
        logfile.write("="*80 + "\n\n")

        # Query each email
        for idx, (email, original_password) in enumerate(credentials, 1):
            print(f"[{idx}/{len(credentials)}] {email}...", end=' ')

            result = query_api(email)

            if result:
                count = result.get('count', 0)

                if count > 0:
                    # Analyze breach data
                    analysis = analyze_breach_data(
                        email, original_password, result
                    )

                    exact = analysis['exact_matches']
                    total = analysis['total_count']
                    pwd_match = analysis['password_in_breach']

                    status = "⚠ CRITICAL" if pwd_match else "✓ Found"
                    print(f"{status} {exact}/{total} matches" +
                          (" - PASSWORD EXPOSED!" if pwd_match else ""))

                    # Write to CSV
                    writer.writerow({
                        'email': email,
                        'original_password': original_password or 'N/A',
                        'total_breaches': total,
                        'exact_email_matches': exact,
                        'password_compromised': 'YES' if pwd_match else 'NO',
                        'unique_passwords_found': ', '.join(
                            analysis['unique_passwords']
                        ),
                        'all_breached_entries': ' | '.join(
                            analysis['all_exact_entries']
                        )
                    })

                    # Write detailed log
                    logfile.write(f"\n{'='*80}\n")
                    logfile.write(f"Email: {email}\n")
                    logfile.write(f"Original Password: {original_password}\n")
                    logfile.write(f"Total Breaches Found: {total}\n")
                    logfile.write(f"Exact Email Matches: {exact}\n")
                    logfile.write(
                        f"Password Compromised: "
                        f"{'YES ⚠' if pwd_match else 'NO'}\n"
                    )
                    logfile.write(f"\nUnique Passwords Found ({len(analysis['unique_passwords'])}):\n")  # noqa: E501
                    for pwd in analysis['unique_passwords']:
                        match_marker = " ⚠ CURRENT PASSWORD" if pwd == original_password else ""  # noqa: E501
                        logfile.write(f"  - {pwd}{match_marker}\n")

                    if analysis['all_exact_entries']:
                        logfile.write("\nExact Email Matches:\n")
                        for entry in analysis['all_exact_entries']:
                            logfile.write(f"  {entry}\n")

                    if analysis['all_related_entries']:
                        logfile.write(
                            f"\nRelated Entries "
                            f"({len(analysis['all_related_entries'])}):\n"
                        )
                        for entry in analysis['all_related_entries'][:10]:
                            logfile.write(f"  {entry}\n")
                        if len(analysis['all_related_entries']) > 10:
                            remaining = (len(analysis['all_related_entries'])
                                         - 10)
                            logfile.write(
                                f"  ... and {remaining} more\n"
                            )

                else:
                    print("✓ Clean - No breaches found")
                    writer.writerow({
                        'email': email,
                        'original_password': original_password or 'N/A',
                        'total_breaches': 0,
                        'exact_email_matches': 0,
                        'password_compromised': 'NO',
                        'unique_passwords_found': '',
                        'all_breached_entries': ''
                    })

                    logfile.write(f"\n{'='*80}\n")
                    logfile.write(f"Email: {email}\n")
                    logfile.write("Status: ✓ CLEAN - No breaches found\n")

            else:
                print("✗ API error")
                writer.writerow({
                    'email': email,
                    'original_password': original_password or 'N/A',
                    'total_breaches': 'ERROR',
                    'exact_email_matches': 'ERROR',
                    'password_compromised': 'ERROR',
                    'unique_passwords_found': '',
                    'all_breached_entries': ''
                })

                logfile.write(f"\n{'='*80}\n")
                logfile.write(f"Email: {email}\n")
                logfile.write("Status: ✗ API ERROR\n")

            # Rate limiting - be nice to the API
            if idx < len(credentials):
                time.sleep(1)  # 1 second between requests

    print(f"\n[✓] {input_file} complete! Results saved to:")
    print(f"    - {output_file} (CSV summary)")
    print(f"    - {detailed_log} (Detailed report)")


def main():
    """Main function to process all CSV files."""
    # Define all input files to process
    input_files = [
        'list.csv',
        'alta.csv',
        'amc.csv',
        'ebth.csv',
        'fandango.csv',
        'fresh.csv',
        'frontier.csv',
        'gamestop.csv',
        'marriott.csv',
        'nike.csv',
        'panda.csv',
        'sephora.csv'
    ]

    print("="*80)
    print("Breach Around - Breach Checker and OSINT toolkit - Multiple File Processor")
    print("="*80)
    print(f"Files to process: {len(input_files)}")
    print()

    # Process each file
    for input_file in input_files:
        # Check if file exists
        try:
            with open(input_file, 'r'):
                pass
        except FileNotFoundError:
            print(f"[!] Skipping {input_file} - file not found")
            continue

        # Generate output filenames
        base_name = input_file.replace('.csv', '')
        output_file = f'result-{base_name}.csv'
        detailed_log = f'result-{base_name}-detailed.txt'

        # Process the file
        process_file(input_file, output_file, detailed_log)

    print("\n" + "="*80)
    print("[✓] All files processed successfully!")
    print("="*80)


if __name__ == '__main__':
    main()
