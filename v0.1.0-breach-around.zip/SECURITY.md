# Security Policy

## Reporting a Vulnerability
- Email: security@fusedgaming.com
- Provide reproduction steps, logs (sanitized), and impact assessment.

## Supported Versions
- 0.1.x (current internal preview)

## Expectations
- Do not test production APIs without written approval.
- Never share breach data or credentials in tickets; use redacted samples.
