#!/bin/bash
# Breach Around - Breach Checker and OSINT toolkit - Quick Start Script for Linux/Mac
# This script activates the virtual environment and runs the unified breach checker

echo "==============================================================================="
echo "Breach Around - Breach Checker and OSINT toolkit"
echo "Unified Multi-Service Breach + OSINT Workflow"
echo "==============================================================================="
echo ""

# Check if virtual environment exists
if [ ! -f "bin/activate" ]; then
    echo "ERROR: Virtual environment not found!"
    echo "Please run setup first:"
    echo "  python3 -m venv ."
    echo "  source bin/activate"
    echo "  pip install -r requirements.txt"
    exit 1
fi

# Activate virtual environment
source bin/activate

# Check if input file was provided
if [ -z "$1" ]; then
    echo "Usage: ./run_checker.sh <input_csv_file> [options]"
    echo ""
    echo "Examples:"
    echo "  ./run_checker.sh input_data/list.csv"
    echo "  ./run_checker.sh input_data/nike.csv --hibp --hibp-key YOUR_KEY"
    echo "  ./run_checker.sh input_data/marriott.csv --leakcheck --leakcheck-key YOUR_KEY"
    echo ""
    echo "Available input files:"
    ls -1 input_data/*.csv 2>/dev/null || echo "  (none found)"
    exit 1
fi

# Run the checker
echo "Running Breach Around workflow on $1..."
echo ""
python unified_breach_checker.py "$@"

echo ""
echo "==============================================================================="
echo "Check complete! Results saved to results/ directory"
echo "==============================================================================="
