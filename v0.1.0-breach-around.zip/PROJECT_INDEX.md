# Breach Around - Breach Checker and OSINT toolkit – Repository Index (Fused-Gaming Edition)

## 📁 High-Level Directory Map (2026-01-07)

```
breach-checker/
├── account_validators/           # Per-service validation helpers
├── breach_apis/                  # API integrations (ProxyNova, HIBP, LeakCheck)
├── cloud_checkers/               # Cloud storage/account posture modules
├── docs/
│   ├── architecture/
│   ├── installers/
│   ├── modules/
│   └── releases/
├── input_data/                   # Working CSVs (non-sanitized)
├── logs/                         # Runtime logs (gitignored)
├── outputs/                      # Local exports (gitignored)
├── reports/                      # Investigation reports (gitignored)
├── results/                      # Checker outputs (gitignored)
├── samples/                      # Public-safe sample data (mirrors sanitized releases)
├── sanitized_release/            # Auto-generated clean bundle (ignored)
├── scripts (bat/sh)              # Cross-platform launchers
├── Selenium_Account_Checkers/    # UI automation templates
├── tools/                        # Automation helpers (sanitizer, docs indexer)
└── utils/                        # Shared helpers (credential parser, API helpers)
```

### 🧱 Root-Level Essentials
- `install_via_curl.sh` – curl-installable bootstrap, now reminding users about `clean.sh` rebuild option.
- `clean.sh` – resets caches, recreates `.venv`, and reinstalls dependencies; referenced post-install.
- `version.json` / `VERSION.md` – single source of truth for semantic version + channel.
- `CHANGELOG.md` – chronological history beginning with `0.1.0` migration.
- `ROADMAP.md` – quarterly delivery goals.
- `SECURITY.md` – Fused-Gaming vulnerability reporting policy.
- `manifest.json` – machine-readable manifest for automation (entry points, docs, scripts).
- `LICENSE` – proprietary notice for internal/private releases.
- `.github/milestones.json` – roadmap alignment for automation workflows.
- `docs.json` – auto-generated inventory of the repo root (run `python tools/generate_docs_index.py`).

## 🚀 Quick Start (Updated Paths)

1. **Clone / Update**
   ```bash
   git clone git@github.com:Fused-Gaming/breach-checker.git
   cd K:\git\breach-checker
   ```

2. **Bootstrap Environment**
   ```bash
   python -m venv .venv
   .\.venv\Scripts\activate      # Windows
   # or
   source .venv/bin/activate      # Linux/WSL/macOS
   pip install -r requirements.txt
   ```

   _Shortcut:_ `install_via_curl.sh` handles clone/update, venv creation, dependency install, and surfaces the `clean.sh` reset helper on completion.

3. **Verify Setup**
   ```bash
   python test_setup.py
   ```

4. **Run Checks**
   ```bash
   python unified_breach_checker.py input_data/list.csv
   ```

## 🧩 Module Inventory

| Area | Location | Notes |
| --- | --- | --- |
| APIs | `breach_apis/` | ProxyNova COMB, HaveIBeenPwned, LeakCheck (extensible).
| Validators | `account_validators/` | Service-specific normalization/filters.
| Utilities | `utils/` | Credential parser, API helpers, shared rate limiting.
| Cloud & Selenium | `cloud_checkers/`, `Selenium_Account_Checkers/` | Optional extended surface checks.
| Docs | `docs/` | Architecture, module templates, installer guidance, releases.
| Automation | `tools/` | `create_sanitized_release.py`, `generate_docs_index.py`.
| Installers | Root scripts | `install_via_curl.sh`, `clean.sh`, `run_checker.(bat|sh)`.

## 🧼 Sanitized Release Workflow
1. `python tools/create_sanitized_release.py` – copies repo, strips secrets/logs/outputs, injects `samples/sample_accounts.csv`.
2. Validate `sanitized_release/input_data/` contains sample + `.gitkeep` only.
3. Zip folder → private GitHub release / package feed.
4. Document release in `docs/releases/sanitized_release.md` and update `CHANGELOG.md`/`version.json`.

## 📦 Installer & Post-Install Notes
- `install_via_curl.sh` supports Ubuntu, Debian, WSL, and macOS (best-effort).
- Ensures `git`, `curl`, `python3` exist; creates `.venv` unless `--skip-venv`.
- Finishes with reminders to:
  - Activate `.venv`.
  - Run `python unified_breach_checker.py --help`.
  - Execute `bash clean.sh` from repo root for a full reset / environment rebuild.
- Documentation for these steps lives in `docs/installers/curl_installer.md` and `docs/installers/future_packages.md`.

## 📚 Documentation Stack
- `docs/README.md` – hub overview + contribution guidance.
- `docs/architecture/overview.md` & `data_flow.md` – conceptual diagrams of ingestion → validation → APIs → reporting.
- `docs/modules/existing_modules.md` & `module_template.md` – service catalog + template for upcoming modules.
- `docs/installers/*.md` – curl installer details, future packaging plans.
- `docs/releases/sanitized_release.md` – checklist for producing public-safe bundles.

## 🧾 Day-1 Repository Essentials
These files are expected in every net-new repository cut from this template:

1. **Governance** – `LICENSE`, `SECURITY.md`, `ROADMAP.md`, `.github/milestones.json`.
2. **Versioning** – `version.json`, `VERSION.md`, `CHANGELOG.md`.
3. **Automation Manifests** – `manifest.json`, `docs.json`, `install_via_curl.sh`, `clean.sh`, `tools/*.py`.
4. **Documentation** – `docs/` tree, `BREACH_CHECKER_README.md`, `PROJECT_INDEX.md` (this file), `samples/sample_accounts.csv`.
5. **CI/CD Ready Hooks** – `.github/workflows/` (placeholder) and sanitized release script to feed pipelines.

_If any of the above are missing when spinning up a new repo, replicate them from this project before first commit._

## ✅ Validation & Maintenance Checklist
- [x] `docs.json` regenerated via `python tools/generate_docs_index.py` after structural changes.
- [x] Install script references `clean.sh` so users discover the quick reset utility.
- [x] Paths in README/Quickstart/Setup docs now reference `K:\git\breach-checker`.
- [x] Metadata files (version/roadmap/security/license) committed for organizational compliance.

## ℹ️ Support Tips
1. Run `python test_setup.py` before filing issues.
2. Logs live in `logs/` (gitignored) – include sanitized excerpts when reporting bugs.
3. Prefer running `clean.sh` if virtualenv corruption is suspected.
4. Keep `.env` secrets local; sanitized releases strip `.env` automatically.

---

**Current Version:** 0.1.0  | **Location:** `K:\git\breach-checker\`  | **Status:** Internal stabilization
