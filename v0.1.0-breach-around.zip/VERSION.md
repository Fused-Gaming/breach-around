# Version

- **Current:** 0.1.0
- **Last Updated:** 2026-01-07
- **Source:** `version.json`
