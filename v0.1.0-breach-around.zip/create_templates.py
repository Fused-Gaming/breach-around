#!/usr/bin/env python3
"""Create template CSV files for all services."""
from pathlib import Path

services = [
    'dsw', 'subway', 'roundtable', 'pizzahut', 'dominoes', 'burgerking',
    'hotmail', 'gmail', 'icloud', 'yahoo', 'outlook', 'protonmail', 'aol',
    'paypal', 'venmo', 'cashapp', 'zelle', 'stripe', 'chime', 'navyfederal',
    'usaa', 'regents', 'cwallet', 'wellsfargo', 'bankofamerica', 'chase',
    'facebook', 'instagram', 'twitter', 'x', 'linkedin', 'tiktok',
    'snapchat', 'reddit', 'discord', 'telegram', 'xfinity', 'att',
    'verizon', 'tmobile', 'sprint', 'total', 'simpletalk', 'cricket',
    'boost', 'metrobymetro', 'frontierairlines', 'southwest', 'delta',
    'united', 'american', 'steam', 'epic', 'origin', 'battlenet', 'xbox',
    'playstation', 'netflix', 'hulu', 'disney', 'spotify', 'dropbox',
    'googledrive', 'onedrive', 'icloud_storage', 'amazon', 'walmart',
    'target', 'bestbuy', 'ebay'
]

input_dir = Path('input_data')
input_dir.mkdir(exist_ok=True)

header = 'email:password | Balance = 0 | CertificateValue = 0\n'

for service in services:
    filepath = input_dir / f'{service}.csv'
    if not filepath.exists():
        with open(filepath, 'w') as f:
            f.write(header)
        print(f'[+] Created: {filepath}')
    else:
        print(f'[-] Exists: {filepath}')

print(f'\n[+] All template files ready in {input_dir}/')
