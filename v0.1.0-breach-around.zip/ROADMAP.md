# Breach Around - Breach Checker and OSINT toolkit Roadmap

## Q1 Goals
- Harden sanitized release workflow and automate via GitHub Actions.
- Expand breach_apis coverage with at least two additional providers.
- Package CLI for pip distribution with token-gated premium modules.

## Q2 Goals
- Implement telemetry for run success/failure within private deployments.
- Publish PowerShell installer equivalent to `install_via_curl.sh`.
- Build UI dashboard mockups for reporting outputs.
