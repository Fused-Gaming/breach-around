This directory is required for debugging files
