# Service Validation Status

Last Updated: 2026-01-07

## Status Legend
- ✅ **VALIDATED**: Tested with real data, breach checks working
- 🟡 **READY**: Template created, awaiting test data
- ⚪ **PLANNED**: Future integration

## Service Status Matrix

### Retail & Beauty
| Service | Status | Records Tested | Notes |
|---------|--------|----------------|-------|
| Alta Beauty | ✅ VALIDATED | Yes | Working |
| Sephora | ✅ VALIDATED | Yes | Working |
| DSW | 🟡 READY | - | Template ready |
| Amazon | 🟡 READY | - | Template ready |
| Walmart | 🟡 READY | - | Template ready |
| Target | 🟡 READY | - | Template ready |
| Best Buy | 🟡 READY | - | Template ready |
| eBay | 🟡 READY | - | Template ready |

### Entertainment & Travel
| Service | Status | Records Tested | Notes |
|---------|--------|----------------|-------|
| AMC Theatres | ✅ VALIDATED | Yes | Working |
| Fandango | ✅ VALIDATED | Yes | Working |
| GameStop | ✅ VALIDATED | Yes | Working |
| Marriott | ✅ VALIDATED | Yes | Working |
| Frontier | ✅ VALIDATED | Yes | Working |
| Frontier Airlines | 🟡 READY | - | Template ready |
| Southwest | 🟡 READY | - | Template ready |
| Delta | 🟡 READY | - | Template ready |
| United | 🟡 READY | - | Template ready |
| American | 🟡 READY | - | Template ready |

### Fashion & Apparel
| Service | Status | Records Tested | Notes |
|---------|--------|----------------|-------|
| Nike | ✅ VALIDATED | Yes | Working |

### Food Services
| Service | Status | Records Tested | Notes |
|---------|--------|----------------|-------|
| Panda Express | ✅ VALIDATED | Yes | Working |
| Subway | 🟡 READY | - | Template ready |
| Round Table Pizza | 🟡 READY | - | Template ready |
| Pizza Hut | 🟡 READY | - | Template ready |
| Domino's | 🟡 READY | - | Template ready |
| Burger King | 🟡 READY | - | Template ready |

### Marketplace
| Service | Status | Records Tested | Notes |
|---------|--------|----------------|-------|
| EBTH | ✅ VALIDATED | Yes | Working |
| Fresh (Fresh Market) | ✅ VALIDATED | Yes | Working |

### Email Providers (Priority Testing)
| Service | Status | Records Tested | Notes |
|---------|--------|----------------|-------|
| Gmail | 🟡 READY | - | High priority |
| Hotmail | 🟡 READY | - | High priority |
| Yahoo | 🟡 READY | - | High priority |
| iCloud | 🟡 READY | - | High priority |
| Outlook | 🟡 READY | - | High priority |
| ProtonMail | 🟡 READY | - | Privacy-focused |
| AOL | 🟡 READY | - | Legacy users |

### Payment & Banking (CRITICAL)
| Service | Status | Records Tested | Notes |
|---------|--------|----------------|-------|
| PayPal | 🟡 READY | - | 🚨 CRITICAL |
| Venmo | 🟡 READY | - | 🚨 CRITICAL |
| CashApp | 🟡 READY | - | 🚨 CRITICAL |
| Zelle | 🟡 READY | - | 🚨 CRITICAL |
| Stripe | 🟡 READY | - | 🚨 CRITICAL |
| Chime | 🟡 READY | - | 🚨 CRITICAL |
| Navy Federal | 🟡 READY | - | 🚨 CRITICAL |
| USAA | 🟡 READY | - | 🚨 CRITICAL |
| Wells Fargo | 🟡 READY | - | 🚨 CRITICAL |
| Bank of America | 🟡 READY | - | 🚨 CRITICAL |
| Chase | 🟡 READY | - | 🚨 CRITICAL |
| Regents Bank | 🟡 READY | - | 🚨 CRITICAL |
| CWallet | 🟡 READY | - | 🚨 CRITICAL |

### Social Media
| Service | Status | Records Tested | Notes |
|---------|--------|----------------|-------|
| Facebook | 🟡 READY | - | High priority |
| Instagram | 🟡 READY | - | High priority |
| Twitter/X | 🟡 READY | - | High priority |
| LinkedIn | 🟡 READY | - | Professional |
| TikTok | 🟡 READY | - | High priority |
| Snapchat | 🟡 READY | - | Youth-focused |
| Reddit | 🟡 READY | - | High priority |
| Discord | 🟡 READY | - | Gaming/tech |
| Telegram | 🟡 READY | - | Privacy-focused |

### Telecom/ISP
| Service | Status | Records Tested | Notes |
|---------|--------|----------------|-------|
| Xfinity | 🟡 READY | - | Major ISP |
| AT&T | 🟡 READY | - | Major ISP |
| Verizon | 🟡 READY | - | Major ISP |
| T-Mobile | 🟡 READY | - | Major ISP |
| Sprint | 🟡 READY | - | Legacy |
| Total Wireless | 🟡 READY | - | MVNO |
| SimpleTalk | 🟡 READY | - | MVNO |
| Cricket | 🟡 READY | - | MVNO |
| Boost Mobile | 🟡 READY | - | MVNO |
| Metro by Metro | 🟡 READY | - | MVNO |

### Gaming & Streaming
| Service | Status | Records Tested | Notes |
|---------|--------|----------------|-------|
| Steam | 🟡 READY | - | Major platform |
| Epic Games | 🟡 READY | - | Major platform |
| Origin | 🟡 READY | - | EA platform |
| Battle.net | 🟡 READY | - | Blizzard |
| Xbox | 🟡 READY | - | Microsoft |
| PlayStation | 🟡 READY | - | Sony |
| Netflix | 🟡 READY | - | High priority |
| Hulu | 🟡 READY | - | High priority |
| Disney+ | 🟡 READY | - | High priority |
| Spotify | 🟡 READY | - | High priority |

### Cloud Storage
| Service | Status | Records Tested | Notes |
|---------|--------|----------------|-------|
| Dropbox | 🟡 READY | - | Major platform |
| Google Drive | 🟡 READY | - | Major platform |
| OneDrive | 🟡 READY | - | Microsoft |
| iCloud Storage | 🟡 READY | - | Apple |

## Testing Priority

### Tier 1 - CRITICAL (Test Immediately)
Payment & banking services - any breach here is high-risk

### Tier 2 - HIGH PRIORITY
- Email providers (gateway to other accounts)
- Social media (identity theft risk)
- Cloud storage (data exposure)

### Tier 3 - MEDIUM PRIORITY
- Gaming/streaming (financial info stored)
- Telecom (account takeover risk)

### Tier 4 - STANDARD
- Retail/shopping (payment info risk)
- Food services (loyalty accounts)

## Validation Checklist

When testing a new service:
- [ ] Add test data to `input_data/{service}.csv`
- [ ] Run `python ../check_breaches.py`
- [ ] Verify `result-{service}.csv` generated
- [ ] Check for actual breaches found
- [ ] Run analysis tools to validate cross-referencing
- [ ] Update this status document
- [ ] Mark service as ✅ VALIDATED

## Statistics

- **Total Services**: 78
- **Validated**: 12 (15.4%)
- **Ready for Testing**: 66 (84.6%)
- **Critical Services Pending**: 13 (banking/payment)
