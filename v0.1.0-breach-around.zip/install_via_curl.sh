#!/usr/bin/env bash

set -Eeuo pipefail

DEFAULT_REPO_URL="https://github.com/Fused-Gaming/breach-checker-private.git"
DEFAULT_BRANCH="main"
DEFAULT_DIR="$HOME/breach-checker"

SCRIPT_NAME="install_via_curl.sh"

log() {
  printf '[INFO] %s\n' "$*"
}

warn() {
  printf '[WARN] %s\n' "$*" >&2
}

die() {
  printf '[ERROR] %s\n' "$*" >&2
  exit 1
}

usage() {
  cat <<'EOF'
Usage: curl -fsSL <raw-url> | bash -s -- [options]

Options:
  --repo <url>        Git repository to clone (default: Fused-Gaming private repo)
  --branch <name>     Branch or tag to deploy (default: main)
  --dir <path>        Target installation directory (default: ~/breach-checker)
  --skip-venv         Skip virtual environment creation
  -h, --help          Show this message

The script supports Ubuntu, Debian, and WSL environments. On Windows PowerShell,
invoke via WSL or Git Bash: `bash -c "$(curl -fsSL <url>)"`.
EOF
}

trap 'die "Installation failed on line $LINENO (exit $?)"' ERR

REPO_URL="$DEFAULT_REPO_URL"
REPO_BRANCH="$DEFAULT_BRANCH"
INSTALL_DIR="$DEFAULT_DIR"
CREATE_VENV=1

while (($#)); do
  case "$1" in
    --repo)
      REPO_URL="$2"
      shift 2
      ;;
    --branch)
      REPO_BRANCH="$2"
      shift 2
      ;;
    --dir)
      INSTALL_DIR="$2"
      shift 2
      ;;
    --skip-venv)
      CREATE_VENV=0
      shift
      ;;
    -h|--help)
      usage
      exit 0
      ;;
    *)
      die "Unknown option: $1"
      ;;
  esac
done

detect_platform() {
  local kernel="$(uname -s 2>/dev/null || echo unknown)"
  if [[ "$kernel" == "Linux" ]];
  then
    if grep -qi microsoft /proc/version 2>/dev/null; then
      PLATFORM="WSL"
    else
      PLATFORM="Linux"
    fi
  elif [[ "$kernel" == "Darwin" ]]; then
    PLATFORM="macOS"
  else
    PLATFORM="Unknown"
  fi
  log "Detected platform: $PLATFORM"
  if [[ "$PLATFORM" == "Unknown" ]]; then
    warn "Proceeding with generic POSIX assumptions; ensure bash, git, and python3 are available."
  fi
}

require_commands() {
  local missing=()
  for cmd in "$@"; do
    if ! command -v "$cmd" >/dev/null 2>&1; then
      missing+=("$cmd")
    fi
  done
  if ((${#missing[@]})); then
    warn "Missing commands: ${missing[*]}"
    warn "Install prerequisites. On Ubuntu/WSL: sudo apt update && sudo apt install -y python3 python3-venv python3-pip git curl"
    die "Cannot continue without required tooling."
  fi
}

clone_or_update_repo() {
  if [[ -d "$INSTALL_DIR/.git" ]]; then
    log "Updating existing checkout in $INSTALL_DIR"
    git -C "$INSTALL_DIR" fetch --tags --prune
    git -C "$INSTALL_DIR" checkout "$REPO_BRANCH"
    git -C "$INSTALL_DIR" pull --ff-only origin "$REPO_BRANCH"
  else
    log "Cloning $REPO_URL into $INSTALL_DIR"
    mkdir -p "$INSTALL_DIR"
    git clone --branch "$REPO_BRANCH" "$REPO_URL" "$INSTALL_DIR"
  fi
}

setup_virtualenv() {
  if [[ "$CREATE_VENV" -eq 0 ]]; then
    log "Skipping virtual environment creation as requested."
    PYTHON=python3
    return
  fi
  local venv_dir="$INSTALL_DIR/.venv"
  log "Creating virtual environment at $venv_dir"
  python3 -m venv "$venv_dir"
  if [[ -d "$venv_dir/bin" ]]; then
    PYTHON="$venv_dir/bin/python"
  else
    PYTHON="$venv_dir/Scripts/python.exe"
    if [[ ! -x "$PYTHON" ]]; then
      PYTHON=python3
    fi
  fi
}

install_dependencies() {
  log "Installing Python dependencies"
  "$PYTHON" -m pip install --upgrade pip wheel >/dev/null
  "$PYTHON" -m pip install -r "$INSTALL_DIR/requirements.txt"
}

post_install_message() {
  cat <<EOF

Installation complete.

Activate the environment with:
  source "$INSTALL_DIR/.venv/bin/activate"   # Linux/WSL/macOS
  # or
  "$INSTALL_DIR/.venv/Scripts/Activate.ps1"   # PowerShell

Then run:
  python unified_breach_checker.py --help

Need a fresh slate? Use the helper:
  bash clean.sh                # resets caches, recreates virtual env + deps
from within "$INSTALL_DIR" to quickly re-bootstrap prerequisites.
EOF
}

main() {
  detect_platform
  require_commands git curl python3
  clone_or_update_repo
  setup_virtualenv
  install_dependencies
  post_install_message
}

main "$@"
