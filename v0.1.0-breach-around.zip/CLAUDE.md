# Breach Around – Agent Operations Guide

This document orients AI/agentic workflows (Claude, Factory Droids, GitHub Actions) so they can work autonomously without breaking release policy.

## 1. Repo Overview
- **Name:** Breach Around – Breach Checker and OSINT toolkit
- **Primary Language:** Python 3.10+
- **Entry Points:**
  - `unified_breach_checker.py` – multi-service breach/OSINT pipeline
  - `batch_checker.py`, `account_checker.py` – legacy validators
  - `install_via_curl.sh` – curl-install bootstrapper
- **Automation Helpers:** `tools/create_sanitized_release.py`, `tools/generate_docs_index.py`
- **Docs Hub:** `docs/` (architecture, modules, installers, releases)

## 2. Environment & Commands
| Task | Command |
| --- | --- |
| Install deps | `python -m venv .venv && .venv\Scripts\pip install -r requirements.txt`
| Quick test | `.venv\Scripts\python test_setup.py`
| Run checker | `.venv\Scripts\python unified_breach_checker.py input_data/list.csv`
| Reset env | `bash clean.sh` (recreates venv + reinstalls)
| Generate docs index | `python tools/generate_docs_index.py`
| Build sanitized release | `python tools/create_sanitized_release.py`

> **Agents must always run `test_setup.py` before finalizing work.** If new modules are added, include targeted tests as well.

## 3. File/Directory Rules
- **Never commit:** `.env`, `logs/`, `results/`, `outputs/`, `reports/`, `sanitized_release/`, virtualenv folders (enforced via `.gitignore`).
- **Sensitive CSVs:** everything in `input_data/` except `.gitkeep` and sanitized samples must be excluded from public releases.
- **Docs.json:** regenerate after structural changes to keep automated tooling accurate.
- **manifest.json:** update `version_file` + entry points when adding new CLIs.

## 4. Branch & Versioning
- Use semantic version in `version.json` and mirror in `VERSION.md` + `CHANGELOG.md`.
- Update `ROADMAP.md` only when roadmaps change; keep existing milestones intact.
- Default branch: `master` (currently uncommitted). Coordinate with humans before creating release branches.

## 5. Release Workflow (Sanitized)
1. `python tools/create_sanitized_release.py`
2. Verify `sanitized_release/input_data/` only contains `.gitkeep` + `sample_accounts.csv`
3. Run `test_setup.py` inside sanitized copy if feasible.
4. Zip `sanitized_release/`, upload to private GitHub release, and attach checksums.
5. Update `docs/releases/sanitized_release.md`, `CHANGELOG.md`, and version files.

## 6. Pull Request Expectations
- Include summary, testing output (`test_setup.py`, plus any relevant module tests).
- Highlight impacts on installers, docs, or sanitized release tooling.
- Ensure `.github/milestones.json` stays consistent with `ROADMAP.md`.

## 7. Security & Compliance
- Never embed API keys or customer data.
- Sanitized releases must exclude `results/`, `reports/`, `outputs/`, and logs.
- If new breach APIs are added, document key requirements in `docs/modules/existing_modules.md` and extend templates.

## 8. Agent Checklist Before Exit
1. `git status` clean (besides intended changes).
2. `test_setup.py` passes.
3. Docs updated if behavior/install steps changed.
4. Sanitized release tooling still works (`create_sanitized_release.py`).
5. Summarize changes + tests in final response.

Following this guide ensures every agent contributes safely and keeps the repo release-ready.
