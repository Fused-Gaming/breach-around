# Breach Around - Breach Checker and OSINT toolkit: Multi-File Processor

This script checks email addresses from multiple CSV files against the ProxyNova COMB API to identify data breaches.

## Files Processed

The script automatically processes these files:
- `list.csv`
- `alta.csv`
- `amc.csv`
- `ebth.csv`
- `fandango.csv`
- `fresh.csv`
- `frontier.csv`
- `gamestop.csv`
- `marriott.csv`
- `nike.csv`
- `panda.csv`
- `sephora.csv`

## Usage

```bash
cd k:\git\breach-checker
python check_breaches.py
```

The script will:
1. Process each CSV file sequentially
2. Query the ProxyNova API for each email address
3. Generate detailed reports for each file

## Output Files

For each input file (e.g., `list.csv`), the script generates:

### CSV Report: `result-{filename}.csv`
Contains structured data with columns:
- `email` - Email address checked
- `original_password` - Password from the input file
- `total_breaches` - Total breach count from API
- `exact_email_matches` - Number of direct email matches
- `password_compromised` - YES/NO if current password was found
- `unique_passwords_found` - All unique passwords discovered
- `all_breached_entries` - Complete breach entries

### Detailed Report: `result-{filename}-detailed.txt`
Human-readable text report with:
- Complete breach analysis for each email
- List of all unique passwords found
- Warning markers (⚠) for compromised passwords
- All exact email matches
- Sample of related entries

## Console Output

The script provides real-time feedback:
- `✓ Clean` - No breaches found
- `✓ Found` - Breaches found, password not compromised
- `⚠ CRITICAL` - Current password is exposed in breach
- `✗ API error` - Connection or API issue

## Rate Limiting

The script includes 1-second delays between API requests to avoid overwhelming the service.

## Example Output

```
[1/165] 59lnguyen@gmail.com... ✓ Clean - No breaches found
[2/165] azusena007@yahoo.com... ✓ Found 2/5 matches
[3/165] compromised@email.com... ⚠ CRITICAL 3/3 matches - PASSWORD EXPOSED!
```

## Requirements

- Python 3.6+
- `requests` library: `pip install requests`
