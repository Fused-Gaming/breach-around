#!/usr/bin/env python3
"""Create a sanitized snapshot of the project for private releases."""

from __future__ import annotations

import fnmatch
import shutil
from pathlib import Path

PROJECT_ROOT = Path(__file__).resolve().parents[1]
DESTINATION = PROJECT_ROOT / "sanitized_release"
SAMPLE_SOURCE = PROJECT_ROOT / "samples" / "sample_accounts.csv"

EXCLUDED_NAMES = {
    ".git",
    ".venv",
    "Lib",
    "Include",
    "Scripts",
    "backups",
    "logs",
    "outputs",
    "results",
    "reports",
    "sanitized_release",
    "node_modules",
    "dist",
    "build",
    "downloads",
    ".pytest_cache",
    ".mypy_cache",
    ".ruff_cache",
    "__pycache__",
}

EXCLUDED_PATTERNS = [
    "*.pyc",
    "*.pyo",
    "*.pyd",
    "*.log",
    "*.tmp",
    "*.bak",
    "*.swp",
    "result-*.txt",
    "result-*.csv",
    "result-*.json",
    ".env",
    "pyvenv.cfg",
]

SENSITIVE_FILE_PATTERNS = [
    "*.log",
    "*.tmp",
    "*.bak",
    "*.swp",
    "wallet_findings.json",
    "result-*.txt",
    "result-*.csv",
    "result-*.json",
    ".env",
    "pyvenv.cfg",
]

INPUT_DATA_KEEP = {".gitkeep", "sample_accounts.csv"}


def _ignore_filter(_src: str, names: list[str]) -> set[str]:
    ignored: set[str] = set()
    ignored.update(name for name in names if name in EXCLUDED_NAMES)
    for pattern in EXCLUDED_PATTERNS:
        ignored.update(fnmatch.filter(names, pattern))
    return ignored


def clean_input_data(root: Path) -> None:
    target = root / "input_data"
    if not target.exists():
        return
    for child in target.iterdir():
        if child.name in INPUT_DATA_KEEP:
            continue
        if child.is_dir():
            shutil.rmtree(child)
        else:
            child.unlink()
    sample = target / "sample_accounts.csv"
    if SAMPLE_SOURCE.exists():
        sample.write_text(SAMPLE_SOURCE.read_text(encoding="utf-8"), encoding="utf-8")
    else:
        sample.write_text(
            "email,username,password\nexample@example.com,,strong-password\n",
            encoding="utf-8",
        )


def purge_sensitive_files(root: Path) -> None:
    for pattern in SENSITIVE_FILE_PATTERNS:
        for candidate in root.rglob(pattern):
            if candidate.is_file():
                candidate.unlink()


def main() -> None:
    if DESTINATION.exists():
        shutil.rmtree(DESTINATION)
    shutil.copytree(PROJECT_ROOT, DESTINATION, ignore=_ignore_filter)
    clean_input_data(DESTINATION)
    purge_sensitive_files(DESTINATION)
    print(f"Sanitized release created at {DESTINATION}")


if __name__ == "__main__":
    main()
