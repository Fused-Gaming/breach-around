#!/usr/bin/env python3
"""Generate docs.json inventory for top-level project entries."""

from __future__ import annotations

import json
import os
import time
from pathlib import Path

PROJECT_ROOT = Path(__file__).resolve().parents[1]
OUTPUT_FILE = PROJECT_ROOT / "docs.json"
EXCLUDED = {".git"}


def collect_entries() -> list[dict[str, object]]:
    entries: list[dict[str, object]] = []
    for path in sorted(PROJECT_ROOT.iterdir(), key=lambda p: p.name.lower()):
        if path.name in EXCLUDED:
            continue
        info: dict[str, object] = {
            "name": path.name,
            "type": "directory" if path.is_dir() else "file",
            "size_bytes": path.stat().st_size if path.is_file() else None,
            "modified": time.strftime("%Y-%m-%dT%H:%M:%S", time.localtime(path.stat().st_mtime)),
        }
        if path.is_dir():
            try:
                info["children"] = sorted(os.listdir(path))
            except PermissionError:
                info["children"] = []
        entries.append(info)
    return entries


def main() -> None:
    inventory = {
        "generated": time.strftime("%Y-%m-%dT%H:%M:%S"),
        "root": str(PROJECT_ROOT),
        "entries": collect_entries(),
    }
    OUTPUT_FILE.write_text(json.dumps(inventory, indent=2), encoding="utf-8")
    print(f"docs index written to {OUTPUT_FILE}")


if __name__ == "__main__":
    main()
