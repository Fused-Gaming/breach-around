#!/usr/bin/env python3
"""
OSINT Enrichment Module
Cross-reference breached accounts with public intelligence sources
"""
import re
import json
import requests
from pathlib import Path
from typing import Dict, List, Optional
from collections import defaultdict
import dns.resolver


class OSINTEnrichment:
    """Enrich breach data with OSINT sources."""

    def __init__(self):
        self.email_pattern = re.compile(r'^[a-zA-Z0-9._%+-]+@[a-zA-Z0-9.-]+\.[a-zA-Z]{2,}$')

    def validate_email_format(self, email: str) -> bool:
        """Validate email format."""
        return bool(self.email_pattern.match(email))

    def extract_domain(self, email: str) -> Optional[str]:
        """Extract domain from email."""
        if '@' in email:
            return email.split('@')[1].lower()
        return None

    def check_mx_records(self, domain: str) -> Dict:
        """Check if domain has valid MX records."""
        try:
            mx_records = dns.resolver.resolve(domain, 'MX')
            return {
                'has_mx': True,
                'mx_count': len(mx_records),
                'mx_servers': [str(mx.exchange) for mx in mx_records]
            }
        except Exception as e:
            return {'has_mx': False, 'error': str(e)}

    def identify_email_provider(self, email: str) -> Dict:
        """Identify email provider and type."""
        domain = self.extract_domain(email)
        if not domain:
            return {'type': 'invalid'}

        # Common providers
        providers = {
            'gmail.com': {'provider': 'Google', 'type': 'consumer'},
            'googlemail.com': {'provider': 'Google', 'type': 'consumer'},
            'outlook.com': {'provider': 'Microsoft', 'type': 'consumer'},
            'hotmail.com': {'provider': 'Microsoft', 'type': 'consumer'},
            'live.com': {'provider': 'Microsoft', 'type': 'consumer'},
            'yahoo.com': {'provider': 'Yahoo', 'type': 'consumer'},
            'icloud.com': {'provider': 'Apple', 'type': 'consumer'},
            'me.com': {'provider': 'Apple', 'type': 'consumer'},
            'aol.com': {'provider': 'AOL', 'type': 'consumer'},
            'protonmail.com': {'provider': 'ProtonMail', 'type': 'privacy'},
            'proton.me': {'provider': 'ProtonMail', 'type': 'privacy'},
            'tutanota.com': {'provider': 'Tutanota', 'type': 'privacy'},
        }

        if domain in providers:
            return providers[domain]

        # Check for business email patterns
        if any(tld in domain for tld in ['.edu', '.gov', '.mil']):
            return {'provider': 'Institution', 'type': 'institutional'}

        return {'provider': 'Unknown', 'type': 'business/custom'}

    def enumerate_social_media_presence(self, email: str) -> Dict:
        """
        Generate likely social media usernames from email.
        NOTE: This generates likely profiles, not confirmed accounts.
        """
        username = email.split('@')[0]
        domain = self.extract_domain(email)

        # Common username variations
        variations = [
            username,
            username.replace('.', ''),
            username.replace('_', ''),
            username.replace('-', ''),
        ]

        # Generate likely profile URLs
        profiles = {
            'github': [f'https://github.com/{v}' for v in variations],
            'twitter': [f'https://twitter.com/{v}' for v in variations],
            'linkedin': [f'https://linkedin.com/in/{v}' for v in variations],
            'instagram': [f'https://instagram.com/{v}' for v in variations],
            'reddit': [f'https://reddit.com/user/{v}' for v in variations],
        }

        return {
            'username_base': username,
            'likely_profiles': profiles,
            'note': 'URLs are generated guesses - verify manually'
        }

    def analyze_password_patterns(self, passwords: List[str]) -> Dict:
        """Analyze password complexity and patterns."""
        if not passwords:
            return {'analyzed': False}

        patterns = {
            'common_weak': 0,
            'has_numbers': 0,
            'has_special': 0,
            'length_dist': defaultdict(int),
            'starts_with_capital': 0,
            'ends_with_number': 0,
        }

        weak_passwords = ['password', '123456', 'qwerty', 'admin',
                         'letmein', 'welcome', 'monkey', 'dragon']

        for pwd in passwords:
            if not pwd or pwd == 'N/A':
                continue

            # Check weak patterns
            if pwd.lower() in weak_passwords:
                patterns['common_weak'] += 1

            # Complexity
            if any(c.isdigit() for c in pwd):
                patterns['has_numbers'] += 1
            if any(c in '!@#$%^&*()_+-=[]{}|;:,.<>?' for c in pwd):
                patterns['has_special'] += 1

            # Structure
            patterns['length_dist'][len(pwd)] += 1
            if pwd and pwd[0].isupper():
                patterns['starts_with_capital'] += 1
            if pwd and pwd[-1].isdigit():
                patterns['ends_with_number'] += 1

        return {
            'analyzed': True,
            'total_passwords': len(passwords),
            'patterns': dict(patterns)
        }

    def correlate_breach_timeline(self, email_breaches: Dict) -> Dict:
        """
        Correlate breaches by timeline (requires breach date data).
        Currently returns structure for manual population.
        """
        return {
            'email': email_breaches.get('email'),
            'total_breaches': len(email_breaches.get('services', [])),
            'services': email_breaches.get('services', []),
            'note': 'Add breach dates for timeline correlation'
        }

    def generate_osint_report(self, email: str, breach_data: Dict) -> Dict:
        """Generate comprehensive OSINT report for an email."""

        # Email validation
        is_valid_format = self.validate_email_format(email)
        domain = self.extract_domain(email)

        # Domain intelligence
        domain_info = {}
        if domain:
            domain_info = {
                'domain': domain,
                'mx_records': self.check_mx_records(domain),
                'provider_type': self.identify_email_provider(email)
            }

        # Social media enumeration
        social_enum = self.enumerate_social_media_presence(email)

        # Password analysis
        passwords = breach_data.get('passwords', [])
        pwd_analysis = self.analyze_password_patterns(passwords)

        # Compile report
        return {
            'email': email,
            'valid_format': is_valid_format,
            'domain_intelligence': domain_info,
            'social_media_enumeration': social_enum,
            'password_analysis': pwd_analysis,
            'breach_summary': {
                'total_breaches': breach_data.get('breach_count', 0),
                'services_affected': breach_data.get('services', []),
                'password_compromised': breach_data.get('password_compromised', False)
            },
            'risk_score': self._calculate_risk_score(breach_data, domain_info)
        }

    def _calculate_risk_score(self, breach_data: Dict, domain_info: Dict) -> Dict:
        """Calculate risk score based on breach data and OSINT."""
        score = 0
        factors = []

        # Breach count
        breach_count = breach_data.get('breach_count', 0)
        if breach_count > 5:
            score += 30
            factors.append('Multiple breaches (5+)')
        elif breach_count > 2:
            score += 15
            factors.append('Multiple breaches (3-5)')

        # Password compromised
        if breach_data.get('password_compromised'):
            score += 40
            factors.append('Active password compromised')

        # Email provider type
        provider_type = domain_info.get('provider_type', {}).get('type', '')
        if provider_type == 'privacy':
            score -= 10  # Privacy-focused email is slightly better
            factors.append('Privacy-focused email (lower risk)')
        elif provider_type == 'business/custom':
            score += 10
            factors.append('Business email (target for corp espionage)')

        # Risk level
        if score >= 50:
            level = 'CRITICAL'
        elif score >= 30:
            level = 'HIGH'
        elif score >= 15:
            level = 'MEDIUM'
        else:
            level = 'LOW'

        return {
            'score': score,
            'level': level,
            'factors': factors
        }


def enrich_breach_results(results_dir: Path = Path('input_data')):
    """Enrich all breach results with OSINT data."""
    enricher = OSINTEnrichment()
    enriched_data = []

    print("="*80)
    print("OSINT ENRICHMENT - Cross-Reference Analysis")
    print("="*80)

    # Load breach results
    result_files = list(results_dir.glob('result-*.csv'))

    if not result_files:
        print("[!] No result files found")
        return

    # Collect all email data
    email_data = defaultdict(lambda: {
        'services': [],
        'passwords': [],
        'breach_count': 0,
        'password_compromised': False
    })

    import csv
    for result_file in result_files:
        if result_file.stat().st_size == 0:
            continue

        service = result_file.stem.replace('result-', '')

        with open(result_file, 'r', encoding='utf-8') as f:
            reader = csv.DictReader(f)
            for row in reader:
                email = row.get('email', '').lower()
                if not email or email == 'ERROR':
                    continue

                email_data[email]['services'].append(service)
                email_data[email]['breach_count'] += 1

                pwd = row.get('original_password', '')
                if pwd and pwd != 'N/A':
                    email_data[email]['passwords'].append(pwd)

                if row.get('password_compromised') == 'YES':
                    email_data[email]['password_compromised'] = True

    print(f"[*] Enriching {len(email_data)} unique email addresses...")

    # Generate OSINT reports
    high_risk_count = 0
    for email, breach_info in list(email_data.items())[:50]:  # Limit to 50 for speed
        report = enricher.generate_osint_report(email, breach_info)
        enriched_data.append(report)

        if report['risk_score']['level'] in ['CRITICAL', 'HIGH']:
            high_risk_count += 1

    # Save enriched data
    output_file = 'osint_enriched_report.json'
    with open(output_file, 'w') as f:
        json.dump(enriched_data, f, indent=2)

    print(f"\n[+] OSINT enrichment complete!")
    print(f"    - Emails analyzed: {len(enriched_data)}")
    print(f"    - High/Critical risk: {high_risk_count}")
    print(f"    - Report saved: {output_file}")
    print("="*80)

    return enriched_data


if __name__ == '__main__':
    enrich_breach_results()
