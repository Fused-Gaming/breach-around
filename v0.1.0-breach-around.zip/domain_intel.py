#!/usr/bin/env python3
"""
Domain Intelligence Module
Analyze email domains for organizational intelligence
"""
import csv
from pathlib import Path
from collections import defaultdict, Counter
import json


def analyze_domain_distribution():
    """Analyze domain distribution across breached accounts."""

    domain_stats = defaultdict(lambda: {
        'count': 0,
        'services': set(),
        'compromised_count': 0,
        'emails': []
    })

    # Collect data
    input_dir = Path('input_data')
    for result_file in input_dir.glob('result-*.csv'):
        if result_file.stat().st_size == 0:
            continue

        service = result_file.stem.replace('result-', '')

        with open(result_file, 'r', encoding='utf-8') as f:
            reader = csv.DictReader(f)
            for row in reader:
                email = row.get('email', '').lower()
                if not email or email == 'ERROR' or '@' not in email:
                    continue

                domain = email.split('@')[1]
                domain_stats[domain]['count'] += 1
                domain_stats[domain]['services'].add(service)
                domain_stats[domain]['emails'].append(email)

                if row.get('password_compromised') == 'YES':
                    domain_stats[domain]['compromised_count'] += 1

    # Analysis
    print("="*80)
    print("DOMAIN INTELLIGENCE REPORT")
    print("="*80)

    # Top domains by breach count
    print("\n[*] Top Domains by Breach Count:")
    sorted_domains = sorted(domain_stats.items(),
                           key=lambda x: x[1]['count'],
                           reverse=True)

    for domain, stats in sorted_domains[:15]:
        print(f"  {domain}:")
        print(f"    - Total breaches: {stats['count']}")
        print(f"    - Unique accounts: {len(set(stats['emails']))}")
        print(f"    - Compromised passwords: {stats['compromised_count']}")
        print(f"    - Services: {', '.join(list(stats['services'])[:5])}")

    # Identify organizations
    print("\n[*] Potential Organizations (non-consumer domains):")
    consumer_domains = ['gmail.com', 'yahoo.com', 'hotmail.com', 'outlook.com',
                       'icloud.com', 'aol.com', 'live.com', 'protonmail.com']

    org_domains = [(d, s) for d, s in sorted_domains
                   if d not in consumer_domains and s['count'] >= 2]

    for domain, stats in org_domains[:10]:
        print(f"  {domain}: {len(set(stats['emails']))} employees affected")

    # Domain type distribution
    print("\n[*] Domain Type Distribution:")
    consumer_count = sum(1 for d in domain_stats.keys() if d in consumer_domains)
    business_count = len(domain_stats) - consumer_count

    print(f"  Consumer email providers: {consumer_count} domains")
    print(f"  Business/Organization emails: {business_count} domains")

    # Save detailed report
    report = {
        'domain_statistics': {
            domain: {
                'breach_count': stats['count'],
                'unique_accounts': len(set(stats['emails'])),
                'compromised_passwords': stats['compromised_count'],
                'services': list(stats['services'])
            }
            for domain, stats in sorted_domains
        },
        'summary': {
            'total_domains': len(domain_stats),
            'consumer_domains': consumer_count,
            'business_domains': business_count
        }
    }

    with open('domain_intelligence_report.json', 'w') as f:
        json.dump(report, f, indent=2)

    print(f"\n[+] Report saved: domain_intelligence_report.json")
    print("="*80)


if __name__ == '__main__':
    analyze_domain_distribution()
