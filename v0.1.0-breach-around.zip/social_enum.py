#!/usr/bin/env python3
"""
Social Media Enumeration
Check if emails are registered on major platforms
Uses public signup/password-reset endpoints to detect account existence
"""
import requests
import time
from typing import Dict, List
import json
from pathlib import Path
import csv


class SocialMediaEnumerator:
    """Enumerate social media accounts by email."""

    def __init__(self):
        self.session = requests.Session()
        self.session.headers.update({
            'User-Agent': 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36'
        })

    def check_twitter(self, email: str) -> Dict:
        """Check if email registered on Twitter/X."""
        # Twitter signup endpoint check
        url = 'https://api.twitter.com/i/users/email_available.json'
        try:
            response = self.session.get(url, params={'email': email}, timeout=5)
            if response.status_code == 200:
                data = response.json()
                return {
                    'platform': 'twitter',
                    'exists': not data.get('valid', True),
                    'method': 'api'
                }
        except Exception as e:
            return {'platform': 'twitter', 'exists': 'unknown', 'error': str(e)}

    def check_instagram(self, email: str) -> Dict:
        """Check if email registered on Instagram."""
        # Note: Instagram has rate limiting
        return {'platform': 'instagram', 'exists': 'check_manually',
                'note': 'Use password reset flow or holehe tool'}

    def check_facebook(self, email: str) -> Dict:
        """Check if email registered on Facebook."""
        return {'platform': 'facebook', 'exists': 'check_manually',
                'note': 'Use password reset flow or holehe tool'}

    def check_linkedin(self, email: str) -> Dict:
        """Check if email registered on LinkedIn."""
        return {'platform': 'linkedin', 'exists': 'check_manually',
                'note': 'Use password reset flow'}

    def check_github(self, email: str) -> Dict:
        """Check if email registered on GitHub."""
        # GitHub doesn't have public email check API
        return {'platform': 'github', 'exists': 'check_manually',
                'note': 'Search commits or use username enumeration'}

    def enumerate_all(self, email: str) -> Dict:
        """Enumerate all platforms for an email."""
        results = {
            'email': email,
            'platforms': []
        }

        # Check each platform (add delay to respect rate limits)
        platforms = [
            self.check_twitter,
            self.check_instagram,
            self.check_facebook,
            self.check_linkedin,
            self.check_github
        ]

        for check_func in platforms:
            result = check_func(email)
            results['platforms'].append(result)
            time.sleep(1)  # Rate limiting

        return results


def enumerate_breached_accounts(limit: int = 20):
    """Enumerate social media for breached accounts."""
    enumerator = SocialMediaEnumerator()

    print("="*80)
    print("SOCIAL MEDIA ENUMERATION")
    print("="*80)
    print(f"[!] Note: This performs limited checks due to rate limiting.")
    print(f"[!] For comprehensive checks, use tools like:")
    print(f"    - holehe (pip install holehe)")
    print(f"    - sherlock (username enumeration)")
    print(f"    - maigret (OSINT framework)")
    print("="*80)

    # Load high-risk emails from analysis
    try:
        with open('breach_analysis_report.json', 'r') as f:
            analysis = json.load(f)
            high_priority = analysis.get('high_priority_compromised', [])
            emails = [item['email'] for item in high_priority[:limit]]

        if not emails:
            # Fall back to reading from result files
            print("[*] No high-priority list found, sampling from results...")
            emails = []
            input_dir = Path('input_data')
            for result_file in list(input_dir.glob('result-*.csv'))[:3]:
                with open(result_file, 'r', encoding='utf-8') as f:
                    reader = csv.DictReader(f)
                    for i, row in enumerate(reader):
                        if i >= limit // 3:
                            break
                        email = row.get('email', '')
                        if email and email != 'ERROR':
                            emails.append(email)

    except FileNotFoundError:
        print("[!] Run analyze_results.py first")
        return

    print(f"\n[*] Enumerating {len(emails)} email addresses...")
    results = []

    for i, email in enumerate(emails[:limit], 1):
        print(f"[{i}/{len(emails[:limit])}] {email}...")
        enum_result = enumerator.enumerate_all(email)
        results.append(enum_result)

    # Save results
    with open('social_media_enumeration.json', 'w') as f:
        json.dump(results, f, indent=2)

    print(f"\n[+] Enumeration complete! Saved to: social_media_enumeration.json")
    print("\n[*] For comprehensive enumeration, run:")
    print("    pip install holehe")
    print("    holehe <email>")
    print("="*80)


if __name__ == '__main__':
    enumerate_breached_accounts(limit=10)
