#!/bin/bash

VENV_DIR=".venv"
REQUIREMENTS_FILE="requirements.txt"

# Function to find the correct python interpreter (python or python3)
find_python() {
    if command -v python &> /dev/null; then
        echo "python"
    elif command -v python3 &> /dev/null; then
        echo "python3"
    else
        echo "Error: Python not found. Please install Python 3.4+."
        exit 1
    fi
}

PYTHON_CMD=$(find_python)

# Check for the venv module
if ! "$PYTHON_CMD" -m venv --help &> /dev/null; then
    echo "Error: The 'venv' module is not available. Ensure you are using Python 3.4+."
    exit 1
fi

# Create the virtual environment if it doesn't exist
if [ ! -d "$VENV_DIR" ]; then
    echo "Creating virtual environment '$VENV_DIR'..."
    "$PYTHON_CMD" -m venv "$VENV_DIR"
    echo "Virtual environment created."
fi

# Activate the virtual environment
echo "Activating virtual environment..."
if [ -f "$VENV_DIR/bin/activate" ]; then # For Linux/macOS
    source "$VENV_DIR/bin/activate"
elif [ -f "$VENV_DIR/Scripts/activate" ]; then # For Windows (Git Bash/WSL)
    source "$VENV_DIR/Scripts/activate"
else
    echo "Error: Activation script not found."
    exit 1
fi

# Install dependencies from requirements.txt if it exists
if [ -f "$REQUIREMENTS_FILE" ]; then
    echo "Installing dependencies from $REQUIREMENTS_FILE..."
    pip install -r "$REQUIREMENTS_FILE"
    echo "Dependencies installed."
else
    echo "Note: $REQUIREMENTS_FILE not found. No packages installed."
fi

echo "Setup complete. The virtual environment '$VENV_DIR' is active."
# The user needs to run this script using 'source' so the venv remains active in their current shell.
