#!/usr/bin/env python3
"""
Helper utilities for API interactions
"""
import time
import logging
from typing import Optional, Dict, Any
import requests
from functools import wraps


# Configure logging
logging.basicConfig(
    level=logging.INFO,
    format='%(asctime)s - %(name)s - %(levelname)s - %(message)s'
)
logger = logging.getLogger(__name__)


def rate_limit(calls: int = 1, period: float = 1.0):
    """
    Decorator to rate limit API calls.

    Args:
        calls: Number of calls allowed per period
        period: Time period in seconds
    """
    min_interval = period / calls
    last_called = [0.0]

    def decorator(func):
        @wraps(func)
        def wrapper(*args, **kwargs):
            elapsed = time.time() - last_called[0]
            left_to_wait = min_interval - elapsed

            if left_to_wait > 0:
                time.sleep(left_to_wait)

            result = func(*args, **kwargs)
            last_called[0] = time.time()
            return result

        return wrapper
    return decorator


def retry_on_failure(max_attempts: int = 3, delay: float = 1.0, backoff: float = 2.0):
    """
    Decorator to retry failed API calls with exponential backoff.

    Args:
        max_attempts: Maximum number of retry attempts
        delay: Initial delay between retries in seconds
        backoff: Backoff multiplier for exponential backoff
    """
    def decorator(func):
        @wraps(func)
        def wrapper(*args, **kwargs):
            current_delay = delay

            for attempt in range(max_attempts):
                try:
                    return func(*args, **kwargs)
                except Exception as e:
                    if attempt == max_attempts - 1:
                        logger.error(f"Failed after {max_attempts} attempts: {e}")
                        raise

                    logger.warning(f"Attempt {attempt + 1} failed: {e}. Retrying in {current_delay}s...")
                    time.sleep(current_delay)
                    current_delay *= backoff

        return wrapper
    return decorator


def make_api_request(
    url: str,
    method: str = 'GET',
    headers: Optional[Dict[str, str]] = None,
    params: Optional[Dict[str, Any]] = None,
    data: Optional[Dict[str, Any]] = None,
    json_data: Optional[Dict[str, Any]] = None,
    timeout: int = 10
) -> Optional[requests.Response]:
    """
    Make an API request with error handling.

    Args:
        url: API endpoint URL
        method: HTTP method (GET, POST, etc.)
        headers: Request headers
        params: URL parameters
        data: Form data
        json_data: JSON data
        timeout: Request timeout in seconds

    Returns:
        Response object or None on failure
    """
    try:
        response = requests.request(
            method=method,
            url=url,
            headers=headers,
            params=params,
            data=data,
            json=json_data,
            timeout=timeout
        )

        # Log non-successful responses
        if response.status_code >= 400:
            logger.warning(f"API request to {url} returned status {response.status_code}")

        return response

    except requests.exceptions.Timeout:
        logger.error(f"Request to {url} timed out after {timeout}s")
        return None
    except requests.exceptions.ConnectionError:
        logger.error(f"Connection error when requesting {url}")
        return None
    except requests.exceptions.RequestException as e:
        logger.error(f"Request error: {e}")
        return None


class APIRateLimiter:
    """
    Rate limiter for API calls.
    """
    def __init__(self, calls_per_second: float = 1.0):
        """
        Initialize rate limiter.

        Args:
            calls_per_second: Maximum number of calls per second
        """
        self.min_interval = 1.0 / calls_per_second
        self.last_call = 0.0

    def wait(self):
        """Wait until next call is allowed."""
        elapsed = time.time() - self.last_call
        if elapsed < self.min_interval:
            time.sleep(self.min_interval - elapsed)
        self.last_call = time.time()


class APIKeyRotator:
    """
    Rotate between multiple API keys.
    """
    def __init__(self, api_keys: list):
        """
        Initialize API key rotator.

        Args:
            api_keys: List of API keys to rotate
        """
        self.api_keys = api_keys
        self.current_index = 0

    def get_next_key(self) -> str:
        """
        Get next API key in rotation.

        Returns:
            Next API key
        """
        key = self.api_keys[self.current_index]
        self.current_index = (self.current_index + 1) % len(self.api_keys)
        return key
