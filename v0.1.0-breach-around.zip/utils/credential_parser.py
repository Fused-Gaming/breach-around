#!/usr/bin/env python3
"""
Utility module for parsing credentials from various formats
"""
import csv
import re
from typing import List, Tuple, Optional
from dataclasses import dataclass


@dataclass
class Credential:
    """Represents a credential with metadata"""
    email: str
    password: Optional[str] = None
    balance: Optional[str] = None
    certificate_value: Optional[str] = None
    source_file: Optional[str] = None
    line_number: Optional[int] = None

    def __str__(self):
        return f"{self.email}:{self.password or 'N/A'}"


def extract_email_and_password(line: str) -> Tuple[Optional[str], Optional[str], Optional[str], Optional[str]]:
    """
    Extract email, password, balance, and certificate value from CSV line.

    Supported formats:
    - email:password | Balance = X | CertificateValue = Y
    - email:password
    - email,password
    - email
    """
    if not line or line.strip() == '':
        return None, None, None, None

    balance = None
    cert_value = None

    # Check for pipe-separated metadata
    if '|' in line:
        parts = line.split('|')
        cred_part = parts[0].strip()

        # Extract balance and certificate value
        for part in parts[1:]:
            part = part.strip()
            if 'Balance' in part or 'balance' in part:
                balance_match = re.search(r'[=:]\s*(\d+\.?\d*)', part)
                if balance_match:
                    balance = balance_match.group(1)
            elif 'Certificate' in part or 'certificate' in part or 'Value' in part:
                cert_match = re.search(r'[=:]\s*(\d+\.?\d*)', part)
                if cert_match:
                    cert_value = cert_match.group(1)
    else:
        cred_part = line.strip()

    # Extract email and password
    email = None
    password = None

    # Try colon separator first
    if ':' in cred_part:
        cred_parts = cred_part.split(':', 1)
        if len(cred_parts) >= 1 and '@' in cred_parts[0]:
            email = cred_parts[0].strip()
            password = cred_parts[1].strip() if len(cred_parts) > 1 else None
    # Try comma separator
    elif ',' in cred_part:
        cred_parts = cred_part.split(',', 1)
        if len(cred_parts) >= 1 and '@' in cred_parts[0]:
            email = cred_parts[0].strip()
            password = cred_parts[1].strip() if len(cred_parts) > 1 else None
    # Just email
    elif '@' in cred_part:
        email = cred_part.strip()

    return email, password, balance, cert_value


def load_credentials_from_csv(file_path: str, skip_header: bool = True) -> List[Credential]:
    """
    Load credentials from a CSV file.

    Args:
        file_path: Path to CSV file
        skip_header: Whether to skip the first line

    Returns:
        List of Credential objects
    """
    credentials = []

    with open(file_path, 'r', encoding='utf-8', errors='ignore') as f:
        for i, line in enumerate(f, 1):
            # Skip header if requested
            if i == 1 and skip_header:
                continue

            email, password, balance, cert_value = extract_email_and_password(line)

            if email:
                credentials.append(Credential(
                    email=email,
                    password=password,
                    balance=balance,
                    certificate_value=cert_value,
                    source_file=file_path,
                    line_number=i
                ))

    return credentials


def validate_email(email: str) -> bool:
    """
    Validate email format.

    Args:
        email: Email address to validate

    Returns:
        True if valid, False otherwise
    """
    pattern = r'^[a-zA-Z0-9._%+-]+@[a-zA-Z0-9.-]+\.[a-zA-Z]{2,}$'
    return bool(re.match(pattern, email))


def sanitize_email(email: str) -> str:
    """
    Sanitize email address by removing extra whitespace and converting to lowercase.

    Args:
        email: Email address to sanitize

    Returns:
        Sanitized email address
    """
    return email.strip().lower()
