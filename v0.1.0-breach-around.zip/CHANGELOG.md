# Changelog
All notable changes to this project will be documented in this file.

## [0.1.0] - 2026-01-07
- Initialized repo metadata after migration to Fused-Gaming organization.
- Added sanitized release tooling, installers, and documentation structure.
- Introduced docs.json index for top-level assets.
