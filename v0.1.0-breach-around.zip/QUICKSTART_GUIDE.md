# Breach Around - Breach Checker and OSINT toolkit: Quick Start Guide

## Complete OSINT & Breach Analysis System
**78 Services | OSINT Enrichment | Cross-Reference Intelligence**

---

## 🚀 Quick Commands

### 1. Basic Breach Check (All Services)
```bash
cd breach-checker
python ../check_breaches.py
```

### 2. Batch Account Validation (Live Checking)
```bash
# Check all accounts with 20 threads
python batch_checker.py -t 20

# With auto-analysis
python batch_checker.py -t 20 --with-analysis

# Single service only
python batch_checker.py -t 20 -s nike
```

### 3. OSINT Analysis Pipeline
```bash
# After breach checking, run full analysis:
python analyze_results.py          # Pattern analysis
python domain_intel.py              # Domain intelligence
python osint_enrichment.py          # OSINT enrichment
python master_report.py             # Master report
```

---

## 📊 What Each Tool Does

### Breach Detection Tools

**check_breaches.py** - Primary breach database checker
- Queries ProxyNova COMB API
- Checks 78 service credential files
- Identifies password compromises
- Generates per-service reports

**batch_checker.py** - Live account validator
- Tests if credentials still work
- Parallel processing (20 threads default)
- HTTP + Selenium support
- Password permutation testing

### OSINT Analysis Tools

**analyze_results.py** - Critical pattern detection
- High-priority banking/payment breaches
- Password reuse across 3+ services
- Cross-service exposure (3+ breaches)
- Risk summary dashboard

**domain_intel.py** - Domain & organizational intelligence
- Top domains by breach count
- Corporate exposure identification
- Consumer vs business email analysis
- Affected employee tracking

**osint_enrichment.py** - Email intelligence enrichment
- Email format validation
- MX record verification
- Email provider identification
- Social media username generation
- Automated risk scoring (CRITICAL/HIGH/MEDIUM/LOW)

**master_report.py** - Comprehensive cross-reference
- Executive summary dashboard
- Risk matrix by severity
- Organizational exposure tracking
- Security recommendations
- CSV export for Excel/Sheets

**social_enum.py** - Social media enumeration
- Profile discovery by email
- Username generation
- Multi-platform checking

**domain_intel.py** - Advanced domain analysis
- Organizational breach tracking
- Employee exposure metrics
- Domain reputation scoring

---

## 📁 File Structure

```
breach-checker/
├── input_data/              # Input credentials (78 CSV files)
│   ├── alta.csv
│   ├── paypal.csv
│   └── ... (78 total)
│
├── Results & Reports:
│   ├── result-*.csv         # Per-service breach results
│   ├── result-*-detailed.txt
│   ├── checked-*.csv        # Live account validation
│   ├── breach_analysis_report.json
│   ├── domain_intelligence_report.json
│   ├── osint_enriched_report.json
│   ├── master_intelligence_report.json
│   └── master_report.csv
│
└── Analysis Tools:
    ├── check_breaches.py
    ├── batch_checker.py
    ├── analyze_results.py
    ├── domain_intel.py
    ├── osint_enrichment.py
    ├── master_report.py
    └── social_enum.py
```

---

## 🎯 Typical Workflow

### Scenario 1: Quick Breach Check
```bash
# 1. Add credentials to input_data/*.csv files
# 2. Run breach checker
python ../check_breaches.py

# 3. Review critical findings
python analyze_results.py
```

### Scenario 2: Full OSINT Investigation
```bash
# 1. Run all breach checks
python ../check_breaches.py

# 2. Run complete analysis pipeline
python analyze_results.py
python domain_intel.py
python osint_enrichment.py
python master_report.py

# 3. Review master_report.csv in Excel
```

### Scenario 3: Live Account Testing + Analysis
```bash
# 1. Validate accounts (parallel, fast)
python batch_checker.py -t 20 --with-analysis

# 2. Results auto-saved with statistics
# 3. Review checked-all-*.csv
```

### Scenario 4: Focus on High-Risk Services
```bash
# Banking/payment only
for service in paypal venmo chase wellsfargo; do
    python batch_checker.py -t 10 -s $service
done

# Then analyze
python analyze_results.py
```

---

## 🔍 Understanding Output

### Breach Check Results (result-*.csv)
| Field | Meaning |
|-------|---------|
| `email` | Email address checked |
| `total_breaches` | Total times found in breaches |
| `exact_email_matches` | Direct email matches |
| `password_compromised` | YES if current password found |
| `unique_passwords_found` | All passwords exposed |

### Analysis Report (breach_analysis_report.json)
```json
{
  "high_priority_compromised": [],  // Banking/payment breaches
  "cross_service_exposure": [],     // Accounts in 3+ breaches
  "summary": {
    "total_emails": 626,
    "compromised": 29,
    "high_priority": 0
  }
}
```

### Master Report (master_report.csv)
Spreadsheet-ready with:
- High-priority accounts section
- Organizational exposure section
- Risk scoring and recommendations

---

## 🚨 Critical Priority Services

### Tier 1 - CRITICAL (Banking/Payment)
- PayPal, Venmo, CashApp, Zelle
- Stripe, Chime
- Navy Federal, USAA, Wells Fargo, Bank of America, Chase
- Regents Bank, CWallet

### Tier 2 - HIGH (Email Providers)
- Gmail, Yahoo, Hotmail/Outlook
- iCloud, ProtonMail, AOL

### Tier 3 - MEDIUM (Social Media)
- Facebook, Instagram, Twitter/X
- LinkedIn, TikTok, Discord

---

## ⚡ Performance Tips

**Fast breach checking:**
- API includes 1-second rate limit (respectful)
- Process ~3600 emails/hour

**Parallel account validation:**
```bash
# Maximum speed (use cautiously)
python batch_checker.py -t 50

# Balanced (recommended)
python batch_checker.py -t 20

# Conservative (rate-limited sites)
python batch_checker.py -t 5
```

**Large datasets:**
- Split into service-specific files
- Run service-by-service with `-s` flag
- Use `--with-analysis` for auto-reporting

---

## 📊 Statistics Dashboard

After running master_report.py, you'll see:

```
[EXECUTIVE SUMMARY]
  Total Emails Analyzed: 626
  Accounts with Compromised Passwords: 29
  High-Priority Banking/Payment Breaches: 0
  Accounts in Multiple Breaches: 4
  Organizations Affected: 10

[RISK MATRIX]
  CRITICAL Risk Accounts: 0
  HIGH Risk Accounts: 2
  Top Organizational Exposures...

[SECURITY RECOMMENDATIONS]
  1. IMMEDIATE: Reset all banking/payment passwords
  2. HIGH: Enable 2FA on financial accounts
  3. MEDIUM: Audit multi-breach accounts
  ...
```

---

## 🛠️ Advanced Options

### Batch Checker Flags
```bash
-d, --directory    # Input directory (default: input_data)
-t, --threads      # Thread count (default: 20)
-s, --service      # Single service only
--no-permutations  # Disable password variants
--with-osint       # Run OSINT after checking
--with-analysis    # Run all analysis tools
```

### Custom Service Testing
```python
# Add to batch_checker.py service_mapping:
'myservice.csv': 'myservice'

# Then run:
python batch_checker.py -s myservice
```

---

## 📚 Additional Resources

- **SERVICES_STATUS.md** - Service validation matrix
- **README-breach-checker.md** - Full documentation
- **Holehe** - Advanced social media enum: `pip install holehe`
- **Sherlock** - Username OSINT: `pip install sherlock`

---

## 🎓 Example Use Cases

### Legal Investigation
```bash
# 1. Check all breaches
python ../check_breaches.py

# 2. Generate legal-ready report
python master_report.py

# 3. Export to CSV for evidence
# Result: master_report.csv
```

### Security Audit
```bash
# 1. Live account validation
python batch_checker.py -t 20

# 2. Identify active compromises
python analyze_results.py

# 3. Domain intelligence for corporate exposure
python domain_intel.py
```

### Threat Intelligence
```bash
# Full OSINT pipeline
python ../check_breaches.py
python analyze_results.py
python domain_intel.py
python osint_enrichment.py
python social_enum.py
python master_report.py

# Result: Comprehensive intelligence package
```

---

**System Status:** 78 services configured | 12 validated | OSINT integrated
**Last Updated:** 2026-01-07
