#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
Test script to verify breach checker setup
"""
import sys
import os
import io

# Fix Windows console encoding
if sys.platform == 'win32':
    sys.stdout = io.TextIOWrapper(sys.stdout.buffer, encoding='utf-8', errors='replace')
    sys.stderr = io.TextIOWrapper(sys.stderr.buffer, encoding='utf-8', errors='replace')

def test_imports():
    """Test that all modules can be imported."""
    print("Testing imports...")
    try:
        import requests
        print("✓ requests")
    except ImportError as e:
        print(f"✗ requests: {e}")
        return False

    try:
        from dotenv import load_dotenv
        print("✓ python-dotenv")
    except ImportError as e:
        print(f"✗ python-dotenv: {e}")
        return False

    try:
        from utils.credential_parser import load_credentials_from_csv, Credential
        print("✓ utils.credential_parser")
    except ImportError as e:
        print(f"✗ utils.credential_parser: {e}")
        return False

    try:
        from utils.api_helpers import rate_limit, make_api_request
        print("✓ utils.api_helpers")
    except ImportError as e:
        print(f"✗ utils.api_helpers: {e}")
        return False

    try:
        from breach_apis.proxynova_comb import ProxyNovaCOMBChecker
        print("✓ breach_apis.proxynova_comb")
    except ImportError as e:
        print(f"✗ breach_apis.proxynova_comb: {e}")
        return False

    try:
        from breach_apis.haveibeenpwned import HaveIBeenPwnedChecker
        print("✓ breach_apis.haveibeenpwned")
    except ImportError as e:
        print(f"✗ breach_apis.haveibeenpwned: {e}")
        return False

    try:
        from breach_apis.leakcheck import LeakCheckChecker
        print("✓ breach_apis.leakcheck")
    except ImportError as e:
        print(f"✗ breach_apis.leakcheck: {e}")
        return False

    return True


def test_directories():
    """Test that required directories exist."""
    print("\nTesting directories...")
    dirs = ['breach_apis', 'utils', 'input_data', 'results', 'logs']
    all_exist = True

    for dir_name in dirs:
        if os.path.exists(dir_name):
            print(f"✓ {dir_name}/")
        else:
            print(f"✗ {dir_name}/ (missing)")
            all_exist = False

    return all_exist


def test_credential_parser():
    """Test credential parser with sample data."""
    print("\nTesting credential parser...")
    from utils.credential_parser import extract_email_and_password, Credential

    test_cases = [
        ("user@test.com:password123 | Balance = 50", "user@test.com", "password123"),
        ("user@test.com:password123", "user@test.com", "password123"),
        ("user@test.com,password123", "user@test.com", "password123"),
        ("user@test.com", "user@test.com", None),
    ]

    for test_input, expected_email, expected_pwd in test_cases:
        email, pwd, _, _ = extract_email_and_password(test_input)
        if email == expected_email and pwd == expected_pwd:
            print(f"✓ Parsed: {test_input[:30]}...")
        else:
            print(f"✗ Failed to parse: {test_input}")
            print(f"  Expected: {expected_email}:{expected_pwd}")
            print(f"  Got: {email}:{pwd}")
            return False

    return True


def test_api_connectivity():
    """Test basic API connectivity (without making actual requests)."""
    print("\nTesting API modules initialization...")

    try:
        from breach_apis.proxynova_comb import ProxyNovaCOMBChecker
        checker = ProxyNovaCOMBChecker()
        print("✓ ProxyNovaCOMBChecker initialized")
    except Exception as e:
        print(f"✗ ProxyNovaCOMBChecker failed: {e}")
        return False

    try:
        from breach_apis.haveibeenpwned import HaveIBeenPwnedChecker
        checker = HaveIBeenPwnedChecker()
        print("✓ HaveIBeenPwnedChecker initialized")
    except Exception as e:
        print(f"✗ HaveIBeenPwnedChecker failed: {e}")
        return False

    return True


def main():
    """Run all tests."""
    print("=" * 80)
    print("Breach Around - Breach Checker and OSINT toolkit Setup Test")
    print("=" * 80)
    print()

    results = []

    # Run tests
    results.append(("Imports", test_imports()))
    results.append(("Directories", test_directories()))
    results.append(("Credential Parser", test_credential_parser()))
    results.append(("API Modules", test_api_connectivity()))

    # Summary
    print("\n" + "=" * 80)
    print("Test Summary")
    print("=" * 80)

    all_passed = True
    for test_name, passed in results:
        status = "✓ PASS" if passed else "✗ FAIL"
        print(f"{status} - {test_name}")
        if not passed:
            all_passed = False

    print("=" * 80)

    if all_passed:
        print("\n🎉 All tests passed! Setup is complete and ready to use.")
        print("\nNext steps:")
        print("  1. Place CSV files in input_data/ directory")
        print("  2. Run: python unified_breach_checker.py input_data/yourfile.csv")
        print("  3. Or use: run_checker.bat input_data\\yourfile.csv (Windows)")
        return 0
    else:
        print("\n⚠️  Some tests failed. Please check the errors above.")
        return 1


if __name__ == '__main__':
    sys.exit(main())
