#!/usr/bin/env python3
"""Quick analysis of breach checker results - identifies critical risks."""
import csv
from pathlib import Path
from collections import defaultdict
import json

# High-priority service categories
HIGH_PRIORITY = ['paypal', 'venmo', 'cashapp', 'stripe', 'chime', 'navyfederal',
                 'usaa', 'wellsfargo', 'bankofamerica', 'chase']
MEDIUM_PRIORITY = ['gmail', 'hotmail', 'yahoo', 'icloud', 'outlook']

def analyze_breaches():
    """Analyze all result files for critical patterns."""

    # Track data
    email_services = defaultdict(list)  # email -> [services]
    password_reuse = defaultdict(set)   # password -> {emails}
    compromised = defaultdict(dict)     # email -> {service: password}

    # Process all result files
    input_dir = Path('input_data')
    for result_file in input_dir.glob('result-*.csv'):
        if result_file.stat().st_size == 0:
            continue

        service = result_file.stem.replace('result-', '')

        with open(result_file, 'r', encoding='utf-8') as f:
            reader = csv.DictReader(f)
            for row in reader:
                email = row.get('email', '').lower()
                pwd = row.get('original_password', '')
                pwd_compromised = row.get('password_compromised', 'NO')

                if not email or email == 'ERROR':
                    continue

                email_services[email].append(service)

                if pwd and pwd != 'N/A':
                    password_reuse[pwd].add(email)

                if pwd_compromised == 'YES':
                    compromised[email][service] = pwd

    # Generate report
    print("="*80)
    print("CRITICAL BREACH ANALYSIS REPORT")
    print("="*80)

    # 1. High-priority compromised accounts
    print("\n[!] HIGH PRIORITY - Banking/Payment Accounts Compromised:")
    high_risk = []
    for email, services in compromised.items():
        for service, pwd in services.items():
            if any(hp in service.lower() for hp in HIGH_PRIORITY):
                high_risk.append((email, service, pwd))
                print(f"  [!] {email} - {service.upper()} - Password: {pwd}")

    if not high_risk:
        print("  [+] No high-priority accounts compromised")

    # 2. Password reuse (3+ accounts)
    print(f"\n[*] Password Reuse Detection (Same password on 3+ accounts):")
    reuse_found = False
    for pwd, emails in sorted(password_reuse.items(), key=lambda x: len(x[1]), reverse=True):
        if len(emails) >= 3:
            reuse_found = True
            print(f"  Password '{pwd}' used by {len(emails)} accounts:")
            for email in sorted(emails)[:5]:
                print(f"    - {email}")
            if len(emails) > 5:
                print(f"    ... and {len(emails)-5} more")

    if not reuse_found:
        print("  [+] No major password reuse detected")

    # 3. Cross-service exposure
    print(f"\n[*] Cross-Service Exposure (Accounts in 3+ breaches):")
    multi_breach = [(e, svcs) for e, svcs in email_services.items() if len(svcs) >= 3]
    multi_breach.sort(key=lambda x: len(x[1]), reverse=True)

    for email, services in multi_breach[:10]:
        print(f"  {email}: {len(services)} services - {', '.join(services[:5])}")
        if len(services) > 5:
            print(f"    ... and {len(services)-5} more")

    if not multi_breach:
        print("  [+] No accounts found in multiple breaches")

    # Summary stats
    print(f"\n[SUMMARY]")
    print(f"  Total unique emails checked: {len(email_services)}")
    print(f"  Accounts with compromised passwords: {len(compromised)}")
    print(f"  High-priority compromises: {len(high_risk)}")
    print(f"  Accounts in 3+ breaches: {len(multi_breach)}")

    # Save JSON report
    report = {
        'timestamp': str(Path('input_data/result-list.csv').stat().st_mtime if Path('input_data/result-list.csv').exists() else ''),
        'high_priority_compromised': [{'email': e, 'service': s, 'password': p} for e, s, p in high_risk],
        'cross_service_exposure': [{'email': e, 'services': s, 'count': len(s)} for e, s in multi_breach],
        'summary': {
            'total_emails': len(email_services),
            'compromised': len(compromised),
            'high_priority': len(high_risk),
            'multi_breach': len(multi_breach)
        }
    }

    with open('breach_analysis_report.json', 'w') as f:
        json.dump(report, f, indent=2)

    print(f"\n[+] Detailed report saved to: breach_analysis_report.json")
    print("="*80)

if __name__ == '__main__':
    analyze_breaches()
