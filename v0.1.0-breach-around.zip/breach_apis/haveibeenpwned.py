#!/usr/bin/env python3
"""
Have I Been Pwned API breach checker
Requires API key for most endpoints (breachedaccount requires paid key)
Free endpoints: pwnedpasswords (password checking only)
"""
import hashlib
import logging
from typing import Optional, Dict, List
import sys
import os

sys.path.append(os.path.dirname(os.path.dirname(os.path.abspath(__file__))))

from utils.api_helpers import make_api_request, rate_limit, retry_on_failure
from utils.credential_parser import Credential

logger = logging.getLogger(__name__)


class HaveIBeenPwnedChecker:
    """
    Checker for Have I Been Pwned API.

    Free features:
    - Password checking via Pwned Passwords (k-anonymity)

    Paid features (requires API key):
    - Breached account lookup
    - Paste account lookup
    """

    BASE_URL = "https://haveibeenpwned.com/api/v3"
    PASSWORDS_URL = "https://api.pwnedpasswords.com"

    def __init__(self, api_key: Optional[str] = None):
        """
        Initialize HIBP checker.

        Args:
            api_key: HIBP API key (optional, required for breachedaccount endpoint)
        """
        self.api_key = api_key
        self.headers = {
            'User-Agent': 'Breach-Checker-Tool',
        }
        if api_key:
            self.headers['hibp-api-key'] = api_key

    @rate_limit(calls=1, period=1.5)  # HIBP rate limit: 1 request per 1.5 seconds
    def check_password(self, password: str) -> Dict:
        """
        Check if password has been pwned using k-anonymity model.
        This endpoint is FREE and does not require API key.

        Args:
            password: Password to check

        Returns:
            Dict with results
        """
        # Hash the password
        sha1_hash = hashlib.sha1(password.encode()).hexdigest().upper()
        prefix = sha1_hash[:5]
        suffix = sha1_hash[5:]

        try:
            # Query API with first 5 characters
            url = f"{self.PASSWORDS_URL}/range/{prefix}"
            response = make_api_request(url, headers=self.headers)

            if not response or response.status_code != 200:
                return {
                    'status': 'error',
                    'message': f'API returned {response.status_code if response else "no response"}'
                }

            # Parse response
            hashes = response.text.split('\r\n')
            for hash_line in hashes:
                hash_suffix, count = hash_line.split(':')
                if hash_suffix == suffix:
                    return {
                        'status': 'pwned',
                        'count': int(count),
                        'message': f'Password found in {count} breaches'
                    }

            return {
                'status': 'clean',
                'count': 0,
                'message': 'Password not found in breaches'
            }

        except Exception as e:
            logger.error(f"Error checking password: {e}")
            return {
                'status': 'error',
                'message': str(e)
            }

    @rate_limit(calls=1, period=1.5)
    def check_account_breaches(self, email: str) -> Optional[List[Dict]]:
        """
        Check if account appears in any breaches.
        Requires paid API key.

        Args:
            email: Email address to check

        Returns:
            List of breach dicts or None on failure
        """
        if not self.api_key:
            logger.warning("API key required for breached account lookup")
            return None

        try:
            url = f"{self.BASE_URL}/breachedaccount/{email}"
            response = make_api_request(url, headers=self.headers)

            if not response:
                return None

            if response.status_code == 200:
                return response.json()
            elif response.status_code == 404:
                # No breaches found
                return []
            else:
                logger.warning(f"API returned {response.status_code} for {email}")
                return None

        except Exception as e:
            logger.error(f"Error checking {email}: {e}")
            return None

    def check_credential(self, credential: Credential, check_password: bool = True) -> Dict:
        """
        Check a credential against HIBP.

        Args:
            credential: Credential to check
            check_password: Whether to check password (free endpoint)

        Returns:
            Dict with check results
        """
        logger.info(f"Checking {credential.email}...")

        result = {
            'email': credential.email,
            'password': credential.password,
            'source': 'Have I Been Pwned'
        }

        # Check password if provided
        if check_password and credential.password:
            pwd_result = self.check_password(credential.password)
            result['password_status'] = pwd_result

        # Check account breaches if API key available
        if self.api_key:
            breaches = self.check_account_breaches(credential.email)
            if breaches is not None:
                result['account_breaches'] = breaches
                result['breach_count'] = len(breaches)
                result['status'] = 'breached' if breaches else 'clean'
                if breaches:
                    result['breach_names'] = [b.get('Name', 'Unknown') for b in breaches]
            else:
                result['status'] = 'error'
                result['error'] = 'Failed to check account breaches'
        else:
            result['status'] = 'partial'
            result['message'] = 'Only password checked (no API key for account lookup)'

        return result


if __name__ == '__main__':
    # Test with free password checking
    checker = HaveIBeenPwnedChecker()

    # Test password
    pwd_result = checker.check_password("password123")
    print("Password check:", pwd_result)

    # Test credential (password only, no account check)
    test_cred = Credential(
        email="test@example.com",
        password="password123"
    )
    result = checker.check_credential(test_cred)
    print("\nFull check:", result)
