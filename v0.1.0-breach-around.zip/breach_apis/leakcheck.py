#!/usr/bin/env python3
"""
LeakCheck.io API breach checker
Requires API key (paid service)
"""
import logging
from typing import Optional, Dict, List
import sys
import os

sys.path.append(os.path.dirname(os.path.dirname(os.path.abspath(__file__))))

from utils.api_helpers import make_api_request, rate_limit, retry_on_failure
from utils.credential_parser import Credential

logger = logging.getLogger(__name__)


class LeakCheckChecker:
    """
    Checker for LeakCheck.io API.
    Requires API key (paid service with free tier available).
    """

    BASE_URL = "https://leakcheck.io/api"

    def __init__(self, api_key: str):
        """
        Initialize LeakCheck checker.

        Args:
            api_key: LeakCheck API key
        """
        self.api_key = api_key
        self.headers = {
            'User-Agent': 'Breach-Checker-Tool',
        }

    @rate_limit(calls=1, period=1.0)
    @retry_on_failure(max_attempts=2, delay=2.0)
    def check_email(self, email: str, check_type: str = 'auto') -> Optional[Dict]:
        """
        Check email against LeakCheck database.

        Args:
            email: Email address to check
            check_type: Type of check ('auto', 'email', 'domain', etc.)

        Returns:
            API response dict or None on failure
        """
        try:
            url = f"{self.BASE_URL}/public"
            params = {
                'key': self.api_key,
                'check': email,
                'type': check_type
            }

            response = make_api_request(url, params=params, headers=self.headers)

            if not response:
                return None

            if response.status_code == 200:
                return response.json()
            elif response.status_code == 404:
                return {'found': 0, 'result': []}
            else:
                logger.warning(f"API returned {response.status_code} for {email}")
                return None

        except Exception as e:
            logger.error(f"Error checking {email}: {e}")
            return None

    def analyze_results(self, email: str, api_result: Dict, original_password: Optional[str] = None) -> Dict:
        """
        Analyze LeakCheck results.

        Args:
            email: Email address
            api_result: API response
            original_password: Original password to check

        Returns:
            Analysis dict
        """
        found = api_result.get('found', 0)
        results = api_result.get('result', [])

        if found == 0:
            return {
                'source': 'LeakCheck',
                'status': 'clean',
                'breach_count': 0,
                'message': 'No breaches found'
            }

        # Extract breach details
        sources = set()
        passwords = set()
        password_compromised = False

        for entry in results:
            # Extract source/database name
            if 'sources' in entry:
                sources.update(entry['sources'])

            # Extract password if present
            if 'line' in entry:
                line = entry['line']
                if ':' in line:
                    _, pwd = line.split(':', 1)
                    passwords.add(pwd)
                    if original_password and pwd == original_password:
                        password_compromised = True

        return {
            'source': 'LeakCheck',
            'status': 'breached',
            'breach_count': found,
            'breach_sources': list(sources),
            'unique_passwords': list(passwords),
            'password_compromised': password_compromised,
            'entries': results
        }

    def check_credential(self, credential: Credential) -> Dict:
        """
        Check a credential against LeakCheck.

        Args:
            credential: Credential to check

        Returns:
            Dict with check results
        """
        logger.info(f"Checking {credential.email}...")

        result = self.check_email(credential.email)

        if not result:
            return {
                'email': credential.email,
                'password': credential.password,
                'status': 'error',
                'error': 'API request failed'
            }

        analysis = self.analyze_results(credential.email, result, credential.password)

        return {
            'email': credential.email,
            'password': credential.password,
            **analysis
        }


if __name__ == '__main__':
    import json

    # Test (requires valid API key)
    api_key = os.getenv('LEAKCHECK_API_KEY', 'YOUR_API_KEY_HERE')

    if api_key != 'YOUR_API_KEY_HERE':
        checker = LeakCheckChecker(api_key)

        test_cred = Credential(
            email="test@example.com",
            password="password123"
        )

        result = checker.check_credential(test_cred)
        print(json.dumps(result, indent=2))
    else:
        print("Set LEAKCHECK_API_KEY environment variable to test")
