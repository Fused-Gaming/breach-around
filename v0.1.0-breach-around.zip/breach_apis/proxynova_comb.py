#!/usr/bin/env python3
"""
ProxyNova COMB API breach checker
Free API for checking against the Compilation of Many Breaches (COMB) database
"""
import json
import logging
from typing import Optional, Dict, List
import sys
import os

# Add parent directory to path
sys.path.append(os.path.dirname(os.path.dirname(os.path.abspath(__file__))))

from utils.api_helpers import make_api_request, rate_limit, retry_on_failure
from utils.credential_parser import Credential

logger = logging.getLogger(__name__)


class ProxyNovaCOMBChecker:
    """
    Checker for ProxyNova COMB API.
    No API key required - free public API.
    """

    BASE_URL = "https://api.proxynova.com/comb"

    def __init__(self, rate_limit_delay: float = 1.0):
        """
        Initialize ProxyNova COMB checker.

        Args:
            rate_limit_delay: Delay between requests in seconds (default 1.0)
        """
        self.rate_limit_delay = rate_limit_delay

    @rate_limit(calls=1, period=1.0)
    @retry_on_failure(max_attempts=3, delay=2.0)
    def check_email(
        self,
        email: str,
        start: int = 0,
        limit: int = 100
    ) -> Optional[Dict]:
        """
        Query ProxyNova COMB API for given email.

        Args:
            email: Email address to check
            start: Starting index for results
            limit: Maximum number of results

        Returns:
            API response dict or None on failure
        """
        try:
            url = f"{self.BASE_URL}?query={email}&start={start}&limit={limit}"
            response = make_api_request(url, timeout=10)

            if response and response.status_code == 200:
                return response.json()
            else:
                logger.warning(f"API returned status {response.status_code if response else 'None'} for {email}")
                return None

        except json.JSONDecodeError:
            logger.error(f"Invalid JSON response for {email}")
            return None
        except Exception as e:
            logger.error(f"Error querying {email}: {e}")
            return None

    def analyze_breach_data(
        self,
        email: str,
        original_password: Optional[str],
        api_result: Dict
    ) -> Dict:
        """
        Analyze breach data and extract detailed information.

        Args:
            email: Email address
            original_password: Original password to compare
            api_result: API response data

        Returns:
            Dict with analysis results
        """
        lines = api_result.get('lines', [])
        count = api_result.get('count', 0)

        # Parse breach entries
        exact_matches = []
        related_entries = []
        unique_passwords = set()
        password_match = False
        breach_sources = set()

        for line in lines:
            if ':' in line:
                breach_email, breach_password = line.split(':', 1)

                # Check if it's an exact email match
                if breach_email.lower() == email.lower():
                    exact_matches.append(line)
                    unique_passwords.add(breach_password)

                    # Check if password matches original
                    if original_password and breach_password == original_password:
                        password_match = True
                else:
                    related_entries.append(line)

        return {
            'source': 'ProxyNova COMB',
            'total_count': count,
            'exact_matches': len(exact_matches),
            'related_entries': len(related_entries),
            'unique_passwords': list(unique_passwords),
            'password_compromised': password_match,
            'all_exact_entries': exact_matches,
            'all_related_entries': related_entries,
            'breach_sources': list(breach_sources)
        }

    def check_credential(self, credential: Credential) -> Dict:
        """
        Check a credential against the COMB database.

        Args:
            credential: Credential object to check

        Returns:
            Dict with check results
        """
        logger.info(f"Checking {credential.email}...")

        result = self.check_email(credential.email)

        if not result:
            return {
                'email': credential.email,
                'password': credential.password,
                'status': 'error',
                'error': 'API request failed'
            }

        count = result.get('count', 0)

        if count == 0:
            return {
                'email': credential.email,
                'password': credential.password,
                'status': 'clean',
                'message': 'No breaches found'
            }

        # Analyze breach data
        analysis = self.analyze_breach_data(
            credential.email,
            credential.password,
            result
        )

        return {
            'email': credential.email,
            'password': credential.password,
            'status': 'breached',
            'analysis': analysis,
            'password_compromised': analysis['password_compromised'],
            'breach_count': analysis['total_count'],
            'exact_matches': analysis['exact_matches']
        }


if __name__ == '__main__':
    # Test the checker
    checker = ProxyNovaCOMBChecker()

    test_cred = Credential(
        email="test@example.com",
        password="password123"
    )

    result = checker.check_credential(test_cred)
    print(json.dumps(result, indent=2))
