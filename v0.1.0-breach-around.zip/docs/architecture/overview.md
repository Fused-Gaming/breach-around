# Architecture Overview

## System Layers
1. **Data Ingestion** – CSV parsers in `utils/credential_parser.py` normalize account records.
2. **Validation & Routing** – `account_checker.py` and supporting validators determine which breach/API modules to call.
3. **Breach APIs** – modules under `breach_apis/` encapsulate third-party integrations with retry and rate-limiting helpers in `utils/api_helpers.py`.
4. **Aggregation & Reporting** – scripts such as `unified_breach_checker.py`, `master_report.py`, and `reports/` builders consolidate outputs.

## Execution Modes
- **Single account** via `account_checker.py`.
- **Batch** via `batch_checker.py` or `unified_breach_checker.py` when pointed at `input_data/*.csv`.
- **Automation** through future GitHub Actions defined in `.github/workflows/`.

## Key Dependencies
- Python 3.10+
- Requests + supporting HTTP libs
- Optional Selenium modules for UI-based flows (`Selenium_Account_Checkers/`).
