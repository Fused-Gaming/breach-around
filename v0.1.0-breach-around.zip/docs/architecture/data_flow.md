# Data Flow

```text
input_data/*.csv --> utils/credential_parser --> account_validators --> breach_apis/*
      |                                                      |
      +--> social_enum/domain_intel (optional)               v
                         reports/master_report <-- unified_breach_checker
```

1. **Inputs** – sanitized samples live in `samples/` and are replicated into `input_data/` during sanitized release builds.
2. **Credential Normalization** – `extract_email_and_password` ensures downstream modules receive consistent tuples.
3. **Validation** – `account_validators/` cleans, deduplicates, and tags records.
4. **API Dispatch** – `breach_apis/*` modules perform network lookups with shared rate limiting helpers.
5. **Results** – standard output captured in `results/` and summarized via reporting scripts; sanitized exports omit PII before publishing.
