# Documentation Hub

## Purpose
- Centralize technical knowledge for the breach checker platform.
- Provide onboarding guidance for future modules and integrations.
- Capture procedures for publishing sanitized installers and releases.

## Structure
1. `architecture/` – high-level and detailed system design references.
2. `modules/` – inventory of current modules plus a template for new ones.
3. `installers/` – platform-specific installation and packaging guides.
4. `releases/` – sanitized release process and compliance checklists.

## How to Contribute
1. Review existing section conventions before adding content.
2. Keep secrets, API keys, and production data out of docs.
3. Cross-link executable scripts or configs to avoid duplication.
