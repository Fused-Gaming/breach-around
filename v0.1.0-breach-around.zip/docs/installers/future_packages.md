# Future Package Distribution

## Goals
1. Offer `pip install fused-breach-checker` for trusted partners.
2. Evaluate npm-style wrapper for JavaScript automation clients.
3. Provide GitHub Gist snippets for rapid bootstrap (curlable installer, PowerShell script).

## Action Items
- Define minimal runtime package (core libs + CLI entry point).
- Separate sensitive breach modules into private extras.
- Automate publishing from sanitized release artifacts.

## Open Questions
- License restrictions for bundled breach APIs?
- How to gate premium modules (tokens vs. GitHub Packages)?
