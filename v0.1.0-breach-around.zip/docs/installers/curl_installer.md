# Curl/Bash Installer

## Script
- Location: `install_via_curl.sh`
- Distribution: host on GitHub (raw URL) for `curl -fsSL ... | bash` usage.

## Supported Platforms
1. Ubuntu / Debian
2. Windows Subsystem for Linux (using Ubuntu base)
3. macOS / Git Bash (best-effort)

## Behavior
1. Detects platform and verifies `git`, `curl`, and `python3` availability.
2. Clones or updates the private repo `git@github.com:Fused-Gaming/breach-checker.git` (override via `--repo`).
3. Creates `.venv` unless `--skip-venv` is passed and installs `requirements.txt`.
4. Prints follow-up commands for activation and running `unified_breach_checker.py`.
5. Highlights the `clean.sh` helper for rebuilding prerequisites/end-to-end setup.

## Fallback Plans
- Publish equivalent PowerShell script if native Windows users cannot leverage WSL.
- Track installer issues in `releases/sanitized_release.md` checklist.
