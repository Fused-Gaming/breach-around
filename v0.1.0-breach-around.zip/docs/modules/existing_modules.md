# Existing Modules

| Category | Location | Notes |
| --- | --- | --- |
| Breach APIs | `breach_apis/` | REST clients for ProxyNova COMB, HaveIBeenPwned, LeakCheck, etc. |
| Account Validators | `account_validators/` | Domain- or service-specific validation helpers. |
| Cloud Checkers | `cloud_checkers/` | Per-provider inventory for storage services. |
| Selenium Checkers | `Selenium_Account_Checkers/` | UI automation flows for providers lacking APIs. |
| Utilities | `utils/` | Shared credential parsing, API helper utilities, logging helpers. |

Each module should document:
1. Supported input schema (email-only, email+password, etc.).
2. Output contract (fields, severity, error handling).
3. External requirements (API keys, proxies, rate limits).
