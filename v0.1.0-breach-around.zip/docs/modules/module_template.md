# Module Design Template

## Summary
- **Goal:**
- **Primary Contacts:**

## Inputs
- Expected CSV columns / parameters
- Required secrets (.env keys)

## Process
1. Describe validation steps.
2. Outline API / scraping interactions.
3. Note rate limiting or retries.

## Outputs
- Data schema returned (JSON structure or CSV columns)
- Error handling strategy

## Testing Checklist
- [ ] Unit tests or mock flows
- [ ] Integration smoke test command
- [ ] Sanitized dataset coverage
