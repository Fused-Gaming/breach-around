# Sanitized Release Process

## Objectives
- Provide a shareable snapshot without PII, logs, or proprietary outputs.
- Bundle a sanitized dataset (`input_data/sample_accounts.csv`).
- Include automation for installers and future CI workflows.

## Steps
1. Run `python tools/create_sanitized_release.py`.
2. Verify `sanitized_release/` excludes:
   - `outputs/`, `results/`, `reports/`
   - `.env`, `pyvenv.cfg`, log files, result exports.
3. Confirm `input_data/` only contains `sample_accounts.csv` + `.gitkeep`.
4. Run `test_setup.py` inside the sanitized copy (optional) to ensure dependencies are intact.
5. Zip the folder and upload to the private GitHub release or package registry.

## Publishing Notes
- Document download + installer usage in `docs/installers/`.
- Track checksum + version metadata alongside the artifact.
- Update release notes with any module interface changes.
