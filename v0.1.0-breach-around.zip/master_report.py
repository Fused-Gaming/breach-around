#!/usr/bin/env python3
"""
Master Cross-Reference Report
Combines all OSINT sources into comprehensive intelligence report
"""
import json
import csv
from pathlib import Path
from collections import defaultdict
from datetime import datetime


def generate_master_report():
    """Generate comprehensive cross-referenced OSINT report."""

    print("="*80)
    print("MASTER CROSS-REFERENCE REPORT")
    print(f"Generated: {datetime.now().strftime('%Y-%m-%d %H:%M:%S')}")
    print("="*80)

    # Load all data sources
    breach_data = load_breach_analysis()
    domain_data = load_domain_intelligence()
    osint_data = load_osint_enrichment()

    # Cross-reference analysis
    master_intel = cross_reference_all(breach_data, domain_data, osint_data)

    # Generate reports
    print_executive_summary(master_intel)
    print_risk_matrix(master_intel)
    print_recommendations(master_intel)

    # Save comprehensive JSON
    with open('master_intelligence_report.json', 'w') as f:
        json.dump(master_intel, f, indent=2)

    # Save CSV for spreadsheet analysis
    export_to_csv(master_intel)

    print(f"\n[+] Master report saved:")
    print(f"    - master_intelligence_report.json")
    print(f"    - master_report.csv")
    print("="*80)


def load_breach_analysis() -> dict:
    """Load breach analysis data."""
    try:
        with open('breach_analysis_report.json', 'r') as f:
            return json.load(f)
    except FileNotFoundError:
        print("[!] breach_analysis_report.json not found")
        return {}


def load_domain_intelligence() -> dict:
    """Load domain intelligence data."""
    try:
        with open('domain_intelligence_report.json', 'r') as f:
            return json.load(f)
    except FileNotFoundError:
        print("[!] domain_intelligence_report.json not found")
        return {}


def load_osint_enrichment() -> dict:
    """Load OSINT enrichment data."""
    try:
        with open('osint_enriched_report.json', 'r') as f:
            return json.load(f)
    except FileNotFoundError:
        print("[!] osint_enriched_report.json not found")
        return []


def cross_reference_all(breach_data, domain_data, osint_data) -> dict:
    """Cross-reference all intelligence sources."""

    master = {
        'timestamp': datetime.now().isoformat(),
        'summary': breach_data.get('summary', {}),
        'high_priority_accounts': [],
        'domain_intelligence': domain_data.get('domain_statistics', {}),
        'risk_profiles': [],
        'organizational_exposure': [],
        'recommendations': []
    }

    # Enhance high-priority accounts with OSINT
    for hp in breach_data.get('high_priority_compromised', []):
        email = hp['email']
        domain = email.split('@')[1] if '@' in email else 'unknown'

        # Find matching OSINT data
        osint_match = next((o for o in osint_data if o.get('email') == email), None)

        enhanced = {
            'email': email,
            'service': hp['service'],
            'password': hp['password'],
            'domain': domain,
            'risk_score': osint_match.get('risk_score', {}) if osint_match else {},
            'provider_type': osint_match.get('domain_intelligence', {}).get(
                'provider_type', {}) if osint_match else {}
        }
        master['high_priority_accounts'].append(enhanced)

    # Identify organizational exposures
    domains = domain_data.get('domain_statistics', {})
    consumer = ['gmail.com', 'yahoo.com', 'hotmail.com', 'outlook.com', 'aol.com']

    for domain, stats in domains.items():
        if domain not in consumer and stats['unique_accounts'] >= 2:
            master['organizational_exposure'].append({
                'organization_domain': domain,
                'affected_accounts': stats['unique_accounts'],
                'total_breaches': stats['breach_count'],
                'compromised_passwords': stats['compromised_passwords'],
                'services': stats['services']
            })

    # Compile risk profiles from OSINT
    for osint in osint_data:
        if osint.get('risk_score', {}).get('level') in ['CRITICAL', 'HIGH']:
            master['risk_profiles'].append({
                'email': osint['email'],
                'risk_level': osint['risk_score']['level'],
                'risk_factors': osint['risk_score']['factors'],
                'breach_count': osint['breach_summary']['total_breaches']
            })

    return master


def print_executive_summary(master: dict):
    """Print executive summary."""
    summary = master['summary']

    print("\n[EXECUTIVE SUMMARY]")
    print(f"  Total Emails Analyzed: {summary.get('total_emails', 0)}")
    print(f"  Accounts with Compromised Passwords: {summary.get('compromised', 0)}")
    print(f"  High-Priority Banking/Payment Breaches: {summary.get('high_priority', 0)}")
    print(f"  Accounts in Multiple Breaches: {summary.get('multi_breach', 0)}")
    print(f"  Organizations Affected: {len(master['organizational_exposure'])}")


def print_risk_matrix(master: dict):
    """Print risk matrix."""
    print("\n[RISK MATRIX]")

    critical = sum(1 for r in master['risk_profiles'] if r['risk_level'] == 'CRITICAL')
    high = sum(1 for r in master['risk_profiles'] if r['risk_level'] == 'HIGH')

    print(f"  CRITICAL Risk Accounts: {critical}")
    print(f"  HIGH Risk Accounts: {high}")

    if master['organizational_exposure']:
        print("\n  Top Organizational Exposures:")
        for org in sorted(master['organizational_exposure'],
                         key=lambda x: x['affected_accounts'],
                         reverse=True)[:5]:
            print(f"    - {org['organization_domain']}: "
                  f"{org['affected_accounts']} accounts, "
                  f"{org['compromised_passwords']} compromised")


def print_recommendations(master: dict):
    """Print security recommendations."""
    print("\n[SECURITY RECOMMENDATIONS]")

    recs = []

    # High-priority breaches
    if master['summary'].get('high_priority', 0) > 0:
        recs.append("IMMEDIATE: Reset all banking/payment account passwords")
        recs.append("IMMEDIATE: Enable 2FA on all financial accounts")

    # Multiple breaches
    if master['summary'].get('multi_breach', 0) > 0:
        recs.append("HIGH: Audit accounts found in 3+ breaches")
        recs.append("HIGH: Consider using unique emails per service")

    # Organizational exposure
    if master['organizational_exposure']:
        recs.append("MEDIUM: Notify affected organizations of employee breaches")
        recs.append("MEDIUM: Implement corporate password policy review")

    # General recommendations
    recs.extend([
        "Use password manager for unique passwords",
        "Enable 2FA/MFA on all critical accounts",
        "Monitor accounts with breach notification services",
        "Consider email aliases for service registration"
    ])

    for i, rec in enumerate(recs, 1):
        print(f"  {i}. {rec}")


def export_to_csv(master: dict):
    """Export master report to CSV."""
    with open('master_report.csv', 'w', newline='', encoding='utf-8') as f:
        writer = csv.writer(f)

        # High-priority accounts
        writer.writerow(['HIGH PRIORITY ACCOUNTS'])
        writer.writerow(['Email', 'Service', 'Domain', 'Risk Level'])

        for account in master['high_priority_accounts']:
            writer.writerow([
                account['email'],
                account['service'],
                account['domain'],
                account.get('risk_score', {}).get('level', 'N/A')
            ])

        writer.writerow([])

        # Organizational exposure
        writer.writerow(['ORGANIZATIONAL EXPOSURE'])
        writer.writerow(['Domain', 'Affected Accounts', 'Total Breaches',
                        'Compromised Passwords'])

        for org in master['organizational_exposure']:
            writer.writerow([
                org['organization_domain'],
                org['affected_accounts'],
                org['total_breaches'],
                org['compromised_passwords']
            ])


if __name__ == '__main__':
    generate_master_report()
