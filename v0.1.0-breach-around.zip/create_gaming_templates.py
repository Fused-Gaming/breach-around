#!/usr/bin/env python3
"""Create template CSV files for gaming and crypto services."""
from pathlib import Path

# New gaming and crypto services
services = [
    # Gaming
    'riot', 'jagex', 'rockstargames', 'ubisoft', 'twitch', 'youtube',
    # Crypto Casinos (HIGH VALUE)
    'stake_com', 'stake_us', 'roobet', 'rollbit', 'shuffle',
    'duelbits', 'csgoempire', 'csgolotto',
    # Crypto Exchanges (CRITICAL)
    'binance', 'coinbase', 'kraken'
]

input_dir = Path('input_data')
input_dir.mkdir(exist_ok=True)

header = 'email:password | Balance = 0 | CertificateValue = 0\n'

created = 0
exists = 0

for service in services:
    filepath = input_dir / f'{service}.csv'
    if not filepath.exists():
        with open(filepath, 'w') as f:
            f.write(header)
        print(f'[+] Created: {filepath}')
        created += 1
    else:
        print(f'[-] Exists: {filepath}')
        exists += 1

print(f'\n[SUMMARY]')
print(f'  Created: {created} new templates')
print(f'  Existed: {exists} already present')
print(f'  Total gaming/crypto services: {len(services)}')
print(f'\n[!] HIGH VALUE SERVICES - Handle with extreme care:')
print(f'    - Crypto Casinos: High balance accounts')
print(f'    - Crypto Exchanges: CRITICAL - 2FA usually required')
print(f'\n[+] All template files ready in {input_dir}/')
